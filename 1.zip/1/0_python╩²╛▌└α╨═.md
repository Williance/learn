### 一，数字(Number)

 int、float、bool、complex

#### 1.数字类型转换

- **int(x)** 将x转换为一个整数。
- **float(x)** 将x转换到一个浮点数。
- **complex(x)** 将x转换到一个复数，实数部分为 x，虚数部分为 0。
- **complex(x, y)** 将 x 和 y 转换到一个复数，实数部分为 x，虚数部分为 y。x 和 y 是数字表达式。

#### 2.数学函数

|                             函数                             |                       返回值 ( 描述 )                        |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| [abs(x)](https://www.nowcoder.com/tutorial/10005/e54cca6bbfe343d49b57dd489dae13db) |             返回数字的绝对值，如abs(-10) 返回 10             |
| [ceil(x)](https://www.nowcoder.com/tutorial/10005/de2b5e19134344df840e19c2cb57318d) |         返回数字的上入整数，如math.ceil(4.1) 返回 5          |
| [exp(x)](https://www.nowcoder.com/tutorial/10005/4e8d51db2c7648729f0fb9355fa33265) |     返回e的x次幂(ex),如math.exp(1) 返回2.718281828459045     |
| [fabs(x)](https://www.nowcoder.com/tutorial/10005/c1942a44197043d4906360872857d10a) |         返回数字的绝对值，如math.fabs(-10) 返回10.0          |
| [floor(x)](https://www.nowcoder.com/tutorial/10005/283be8bde87446f5aab1831cf5af21f0) |         返回数字的下舍整数，如math.floor(4.9)返回 4          |
| [log(x)](https://www.nowcoder.com/tutorial/10005/2942bb4226c341b89767873c217046a5) |      如math.log(math.e)返回1.0,math.log(100,10)返回2.0       |
| [log10(x)](https://www.nowcoder.com/tutorial/10005/ebb804ca9c96448dbe1e72702c4496d7) |      返回以10为基数的x的对数，如math.log10(100)返回 2.0      |
| [max(x1, x2,...)](https://www.nowcoder.com/tutorial/10005/13d206483d5d4753b89961b21a128ad2) |            返回给定参数的最大值，参数可以为序列。            |
| [min(x1, x2,...)](https://www.nowcoder.com/tutorial/10005/5c3c0ad9110a44df9c1b433afb94a739) |            返回给定参数的最小值，参数可以为序列。            |
| [modf(x)](https://www.nowcoder.com/tutorial/10005/fa5691936cd8458cafba2e311f13c174) | 返回x的整数部分与小数部分，两部分的数值符号与x相同，整数部分以浮点型表示。 |
| [pow(x, y)](https://www.nowcoder.com/tutorial/10005/496972d797a84e0d80a596061cb6d959) |                      x**y 运算后的值。                       |
| [round(x [,n\])](https://www.nowcoder.com/tutorial/10005/d303d78aa40d4b5981f4f30d45ff35b0) | 返回浮点数x的四舍五入值，如给出n值，则代表舍入到小数点后的位数。 |
| [sqrt(x)](https://www.nowcoder.com/tutorial/10005/fa4c64b3bee64e279a10db76e2453d50) |                     返回数字x的平方根。                      |

#### 3.随机数函数

|                             函数                             |                             描述                             |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| [choice(seq)](https://www.nowcoder.com/tutorial/10005/2cd0c4821dc44bf39326cb7468579659) | 从序列的元素中随机挑选一个元素，比如random.choice(range(10))，从0到9中随机挑选一个整数。 |
| [randrange ([start,\] stop [,step])](https://www.nowcoder.com/tutorial/10005/90ca55f637a341a4861efca9b388e4ac) | 从指定范围内，按指定基数递增的集合中获取一个随机数，基数默认值为 1 |
| [random()](https://www.nowcoder.com/tutorial/10005/aaadbde4c9bd4ee3a447139452dbda2b) |            随机生成下一个实数，它在[0,1)范围内。             |
| [seed([x\])](https://www.nowcoder.com/tutorial/10005/8893dddc4605496fb00af770837fa27d) | 改变随机数生成器的种子seed。如果你不了解其原理，你不必特别去设定seed，Python会帮你选择seed。 |
| [shuffle(lst)](https://www.nowcoder.com/tutorial/10005/dc3a985df96b492692aca9ce95c2443f) |                   将序列的所有元素随机排序                   |
| [uniform(x, y)](https://www.nowcoder.com/tutorial/10005/2397b64e4fca43f2b734969f302f78d1) |            随机生成下一个实数，它在[x,y]范围内。             |

#### 4.三角函数

|                             函数                             |                       描述                        |
| :----------------------------------------------------------: | :-----------------------------------------------: |
| [acos(x)](https://www.nowcoder.com/tutorial/10005/8dafdf30fd8843e4bb770b7ff095b877) |               返回x的反余弦弧度值。               |
| [asin(x)](https://www.nowcoder.com/tutorial/10005/96fbe220cade4bf599bc269d3f8cd943) |               返回x的反正弦弧度值。               |
| [atan(x)](https://www.nowcoder.com/tutorial/10005/c4ef247c6fdb46ceb6355df17f4e5ee6) |               返回x的反正切弧度值。               |
| [atan2(y, x)](https://www.nowcoder.com/tutorial/10005/0ec39158d3bc40e9b1f08ca8cdc4d6ae) |       返回给定的 X 及 Y 坐标值的反正切值。        |
| [cos(x)](https://www.nowcoder.com/tutorial/10005/3272e4cc28c44e6cb32a66352fe40ba0) |               返回x的弧度的余弦值。               |
| [hypot(x, y)](https://www.nowcoder.com/tutorial/10005/73097816194145208801bb91a8e5d68d) |        返回欧几里德范数 sqrt(x*x + y*y)。         |
| [sin(x)](https://www.nowcoder.com/tutorial/10005/dc26c6e0b50545e2884f3512fad8fec8) |               返回的x弧度的正弦值。               |
| [tan(x)](https://www.nowcoder.com/tutorial/10005/d390af4c4f384bc2a82256c3d7c2bc80) |                返回x弧度的正切值。                |
| [degrees(x)](https://www.nowcoder.com/tutorial/10005/d912a0580ead4b2c80e820f49b9b9560) | 将弧度转换为角度,如degrees(math.pi/2) ， 返回90.0 |
| [radians(x)](https://www.nowcoder.com/tutorial/10005/1d53c2b24ff346cfb4f07376d76ad331) |                 将角度转换为弧度                  |

#### 5.数学常量

| 常量 |                 描述                  |
| :--: | :-----------------------------------: |
|  pi  | 数学常量 pi（圆周率，一般以π来表示）  |
|  e   | 数学常量 e，e即自然常数（自然常数）。 |



### 二，字符串

#### 1.转义字符

| 转义字符 | 描述 |
| :------: | :--: |
|    \n    | 换行 |

#### 2.运算符

下表实例变量a值为字符串 "Hello"，b变量值为 "Python"：

| 操作符 |                             描述                             |              实例               |
| :----: | :----------------------------------------------------------: | :-----------------------------: |
|   +    |                          字符串连接                          |  a + b 输出结果： HelloPython   |
|   *    |                        重复输出字符串                        |    a*2 输出结果：HelloHello     |
|   []   |                   通过索引获取字符串中字符                   |       a[1] 输出结果 **e**       |
| [ : ]  | 截取字符串中的一部分，遵循**左闭右开**原则，str[0,2] 是不包含第 3 个字符的。 |     a[1:4] 输出结果 **ell**     |
|   in   |       成员运算符 - 如果字符串中包含给定的字符返回 True       |   **'H' in a** 输出结果 True    |
| not in |      成员运算符 - 如果字符串中不包含给定的字符返回 True      | **'M' not in a** 输出结果 True  |
|  r/R   |                          原始字符串                          | `print( r'\n' ) print( R'\n' )` |
|   %    |                          格式字符串                          |        请看下一节内容。         |

#### 3.格式化字符串 f-string

f-string在形式上是以 `f` 或 `F` 修饰符引领的字符串（`f'xxx'` 或 `F'xxx'`），以大括号 `{}` 标明被替换的字段；f-string在本质上并不是字符串常量，而是一个在运行时运算求值的表达式。

`{content:format}` 设置字符串格式，其中 `content` 是替换并填入字符串的内容，可以是变量、表达式或函数等，`format` 是格式描述符。采用默认格式时不必指定 `{:format}`，如上面例子所示只写 `{content}` 即可。

<img src="C:\Users\DELL\Desktop\算法学习\f_string.png" alt="f_string" style="zoom:50%;" />

```python
a = 123.4559
b = f'{a:.2f}'  #‘123.46’ 格式化
c = f'{4*5}'    #'20'     表达式 eval（）
```

#### 4.常用函数

|      | 方法及描述                                                   |
| :--- | :----------------------------------------------------------- |
| 1    | [capitalize()](https://www.runoob.com/python3/python3-string-capitalize.html) 将字符串的第一个字符转换为大写 |
| 2    | [center(width, fillchar)](https://www.runoob.com/python3/python3-string-center.html) 返回一个指定的宽度 width 居中的字符串，fillchar 为填充的字符，默认为空格。 |
| 3    | [count(str, beg= 0,end=len(string))](https://www.runoob.com/python3/python3-string-count.html) 返回 str 在 string 里面出现的次数，如果 beg 或者 end 指定则返回指定范围内 str 出现的次数 |
| 4    | [bytes.decode(encoding="utf-8", errors="strict")](https://www.runoob.com/python3/python3-string-decode.html) Python3 中没有 decode 方法，但我们可以使用 bytes 对象的 decode() 方法来解码给定的 bytes 对象，这个 bytes 对象可以由 str.encode() 来编码返回。 |
| 5    | [encode(encoding='UTF-8',errors='strict')](https://www.runoob.com/python3/python3-string-encode.html) 以 encoding 指定的编码格式编码字符串，如果出错默认报一个ValueError 的异常，除非 errors 指定的是'ignore'或者'replace' |
| 6    | [endswith(suffix, beg=0, end=len(string))](https://www.runoob.com/python3/python3-string-endswith.html) 检查字符串是否以 obj 结束，如果beg 或者 end 指定则检查指定的范围内是否以 obj 结束，如果是，返回 True,否则返回 False. |
| 7    | [expandtabs(tabsize=8)](https://www.runoob.com/python3/python3-string-expandtabs.html) 把字符串 string 中的 tab 符号转为空格，tab 符号默认的空格数是 8 。 |
| 8    | [find(str, beg=0, end=len(string))](https://www.runoob.com/python3/python3-string-find.html) 检测 str 是否包含在字符串中，如果指定范围 beg 和 end ，则检查是否包含在指定范围内，如果包含返回开始的索引值，否则返回-1 |
| 9    | [index(str, beg=0, end=len(string))](https://www.runoob.com/python3/python3-string-index.html) 跟find()方法一样，只不过如果str不在字符串中会报一个异常。 |
| 10   | [isalnum()](https://www.runoob.com/python3/python3-string-isalnum.html) 如果字符串至少有一个字符并且所有字符都是字母或数字则返 回 True，否则返回 False |
| 11   | [isalpha()](https://www.runoob.com/python3/python3-string-isalpha.html) 如果字符串至少有一个字符并且所有字符都是字母或中文字则返回 True, 否则返回 False |
| 12   | [isdigit()](https://www.runoob.com/python3/python3-string-isdigit.html) 如果字符串只包含数字则返回 True 否则返回 False.. |
| 13   | [islower()](https://www.runoob.com/python3/python3-string-islower.html) 如果字符串中包含至少一个区分大小写的字符，并且所有这些(区分大小写的)字符都是小写，则返回 True，否则返回 False |
| 14   | [isnumeric()](https://www.runoob.com/python3/python3-string-isnumeric.html) 如果字符串中只包含数字字符，则返回 True，否则返回 False |
| 15   | [isspace()](https://www.runoob.com/python3/python3-string-isspace.html) 如果字符串中只包含空白，则返回 True，否则返回 False. |
| 16   | [istitle()](https://www.runoob.com/python3/python3-string-istitle.html) 如果字符串是标题化的(见 title())则返回 True，否则返回 False |
| 17   | [isupper()](https://www.runoob.com/python3/python3-string-isupper.html) 如果字符串中包含至少一个区分大小写的字符，并且所有这些(区分大小写的)字符都是大写，则返回 True，否则返回 False |
| 18   | [join(seq)](https://www.runoob.com/python3/python3-string-join.html) 以指定字符串作为分隔符，将 seq 中所有的元素(的字符串表示)合并为一个新的字符串 |
| 19   | [len(string)](https://www.runoob.com/python3/python3-string-len.html) 返回字符串长度 |
| 20   | [ljust(width[, fillchar\])](https://www.runoob.com/python3/python3-string-ljust.html) 返回一个原字符串左对齐,并使用 fillchar 填充至长度 width 的新字符串，fillchar 默认为空格。 |
| 21   | [lower()](https://www.runoob.com/python3/python3-string-lower.html) 转换字符串中所有大写字符为小写. |
| 22   | [lstrip()](https://www.runoob.com/python3/python3-string-lstrip.html) 截掉字符串左边的空格或指定字符。 |
| 23   | [maketrans()](https://www.runoob.com/python3/python3-string-maketrans.html) 创建字符映射的转换表，对于接受两个参数的最简单的调用方式，第一个参数是字符串，表示需要转换的字符，第二个参数也是字符串表示转换的目标。 |
| 24   | [max(str)](https://www.runoob.com/python3/python3-string-max.html) 返回字符串 str 中最大的字母。 |
| 25   | [min(str)](https://www.runoob.com/python3/python3-string-min.html) 返回字符串 str 中最小的字母。 |
| 26   | [replace(old, new [, max\])](https://www.runoob.com/python3/python3-string-replace.html) 把 将字符串中的 old 替换成 new,如果 max 指定，则替换不超过 max 次。 |
| 27   | [rfind(str, beg=0,end=len(string))](https://www.runoob.com/python3/python3-string-rfind.html) 类似于 find()函数，不过是从右边开始查找. |
| 28   | [rindex( str, beg=0, end=len(string))](https://www.runoob.com/python3/python3-string-rindex.html) 类似于 index()，不过是从右边开始. |
| 29   | [rjust(width,[, fillchar\])](https://www.runoob.com/python3/python3-string-rjust.html) 返回一个原字符串右对齐,并使用fillchar(默认空格）填充至长度 width 的新字符串 |
| 30   | [rstrip()](https://www.runoob.com/python3/python3-string-rstrip.html) 删除字符串末尾的空格或指定字符。 |
| 31   | [split(str="", num=string.count(str))](https://www.runoob.com/python3/python3-string-split.html) 以 str 为分隔符截取字符串，如果 num 有指定值，则仅截取 num+1 个子字符串 |
| 32   | [splitlines([keepends\])](https://www.runoob.com/python3/python3-string-splitlines.html) 按照行('\r', '\r\n', \n')分隔，返回一个包含各行作为元素的列表，如果参数 keepends 为 False，不包含换行符，如果为 True，则保留换行符。 |
| 33   | [startswith(substr, beg=0,end=len(string))](https://www.runoob.com/python3/python3-string-startswith.html) 检查字符串是否是以指定子字符串 substr 开头，是则返回 True，否则返回 False。如果beg 和 end 指定值，则在指定范围内检查。 |
| 34   | [strip([chars\])](https://www.runoob.com/python3/python3-string-strip.html) 在字符串上执行 lstrip()和 rstrip() |
| 35   | [swapcase()](https://www.runoob.com/python3/python3-string-swapcase.html) 将字符串中大写转换为小写，小写转换为大写 |
| 36   | [title()](https://www.runoob.com/python3/python3-string-title.html) 返回"标题化"的字符串,就是说所有单词都是以大写开始，其余字母均为小写(见 istitle()) |
| 37   | [translate(table, deletechars="")](https://www.runoob.com/python3/python3-string-translate.html) 根据 str 给出的表(包含 256 个字符)转换 string 的字符, 要过滤掉的字符放到 deletechars 参数中 |
| 38   | [upper()](https://www.runoob.com/python3/python3-string-upper.html) 转换字符串中的小写字母为大写 |
| 39   | [zfill (width)](https://www.runoob.com/python3/python3-string-zfill.html) 返回长度为 width 的字符串，原字符串右对齐，前面填充0 |
| 40   | [isdecimal()](https://www.runoob.com/python3/python3-string-isdecimal.html) 检查字符串是否只包含十进制字符，如果是返回 true，否则返回 false。 |

+ startswith() --**前缀树题目**

  用于检查字符串是否是以指定子字符串开头，如果是则返回 True，否则返回 False。如果参数 beg 和 end 指定值，则在指定范围内检查。

  ```python
  str.startswith(substr, beg=0,end=len(string))
  ```

  endswith()

+ find() --**连续字符匹配**（KMP算法）

  ```python
  str.find(substr, beg=0, end=len(string))
  ```

  rfind()
  
  

### 三，列表 [ ]

#### 0.二维列表创建

列表推导式示例

```python
my_list = [i for i in range(10)]
```

创建二维列表

```python
my_list = [[0 for i in range(m)] for j in range(n)]   #m*n 的0
```

#### 1.脚本操作符

|             Python 表达式             |             结果             |         描述         |
| :-----------------------------------: | :--------------------------: | :------------------: |
|            len([1, 2, 3])             |              3               |         长度         |
|         [1, 2, 3] + [4, 5, 6]         |      [1, 2, 3, 4, 5, 6]      |         组合         |
|              ['Hi!'] * 4              | ['Hi!', 'Hi!', 'Hi!', 'Hi!'] |         重复         |
|            3 in [1, 2, 3]             |             True             | 元素是否存在于列表中 |
| for x in [1, 2, 3]: print(x, end=" ") |            1 2 3             |         迭代         |

#### 2.截取

| Python 表达式 |          结果          |                        描述                        |
| :-----------: | :--------------------: | :------------------------------------------------: |
|     L[2]      |        'Taobao'        |                   读取第三个元素                   |
|     L[-2]     |       'Nowcoder'       | 从右侧开始读取倒数第二个元素: count from the right |
|     L[1:]     | ['Nowcoder', 'Taobao'] |          输出从第二个元素开始后的所有元素          |

#### 3.列表函数&方法

| 序号 |                             函数                             |
| :--: | :----------------------------------------------------------: |
|  1   | [len(list)](https://www.nowcoder.com/tutorial/10005/23d7b24085804a08ada617c64ebbc759) 列表元素个数 |
|  2   | [max(list)](https://www.nowcoder.com/tutorial/10005/ee04a2abf2334cc8b19b46030a49c144) 返回列表元素最大值 |
|  3   | [min(list)](https://www.nowcoder.com/tutorial/10005/431133a37dcf4427b8f59dc44cbaa3f0) 返回列表元素最小值 |
|  4   |                 del list[``n``]  按index删除                 |
|  5   | [list(seq)](https://www.nowcoder.com/tutorial/10005/8a19f0b7c7a84371922eed1630e317c4) 将元组转换为列表 |

| 序号 |                             方法                             |
| :--: | :----------------------------------------------------------: |
|  1   | [list.append(obj)](https://www.nowcoder.com/tutorial/10005/e9da215e987d47ffba1e073396c35584) 在列表末尾添加新的对象 |
|  2   | [list.count(obj)](https://www.nowcoder.com/tutorial/10005/04492416803745139eaf3d7f6fac3116) 统计某个元素在列表中出现的次数 |
|  3   | [list.extend(seq)](https://www.nowcoder.com/tutorial/10005/fcd06a81806f44aca30eab67f19ecccf) 在列表末尾一次性追加另一个序列中的多个值（用新列表扩展原来的列表） |
|  4   | [list.index(obj)](https://www.nowcoder.com/tutorial/10005/a057ac85e636480eb8e89ccdc7aded0d) 从列表中找出某个值第一个匹配项的索引位置 |
|  5   | [list.insert(index, obj)](https://www.nowcoder.com/tutorial/10005/94e4dbebd83b48cdb6bb1b590bcddfc6) 将对象插入列表 |
|  6   | [list.pop([index=-1\])](https://www.nowcoder.com/tutorial/10005/29be3fc425054c2285bc6cea868d7c4f) 移除列表中的一个元素（默认最后一个元素），并且返回该元素的值 |
|  7   | [list.remove(obj)](https://www.nowcoder.com/tutorial/10005/d41bf73bd3274ccab8628f6c61952009) 移除列表中某个值的第一个匹配项 |
|  8   | [list.reverse()](https://www.nowcoder.com/tutorial/10005/7d2c4206765c493daf388caa10125f0b) 反向列表中元素 |
|  9   | [list.sort( key=None, reverse=False)](https://www.nowcoder.com/tutorial/10005/892a89d3a09244cebce854b2e04a4518) 对原列表进行排序 |
|  10  | [list.clear()](https://www.nowcoder.com/tutorial/10005/5d28630bd85d4341b8fca0ac17c6eee8) 清空列表 |
|  11  | [list.copy()](https://www.nowcoder.com/tutorial/10005/827e5be29d7b48209327898762072bea) 复制列表 |



### 四，元组 ()

```python
tup1 = (); #创建空元组
```

元组中的元素值是**不允许修改**的，但可以对元组进行连接组合;

元组中的元素值是**不允许删除**的，但可以使用del语句来删除整个元组

#### 1.运算符 -同list

#### 2.截取    -同list

#### 3.内置函数

| 序号 |            方法及描述             |
| :--: | :-------------------------------: |
|  1   |   len(tuple) 计算元组元素个数。   |
|  2   | max(tuple) 返回元组中元素最大值。 |
|  3   | min(tuple) 返回元组中元素最小值。 |
|  4   |   tuple(seq) 将列表转换为元组。   |



### 五，字典

键必须是唯一的，但值则不必。

**值**可以取任何数据类型，但**键**必须是不可变的，如字符串，数字。

```python
dict = {'Name': 'Nowcoder', 'Age': 7, 'Class': 'First'}  #创建字典
dict['Name']                 #访问字典里的值
#修改字典
dict['Age'] = 8              #更新 Age
dict['School'] = "牛客教程"    #添加信息
#删除字典元素
del dict['Name']             #删除键 'Name'
dict.clear()                 #清空字典
del dict                     #删除字典

#处理键不在字典中的情况 --推荐用法
Hash = {}
Hash[val] = Hash.get(val, 0)  #序号4：没有键，即给与默认值0

#众数
mode = max(dict.values())
Mode = [key for key in Hash.keys() if Hash[key] == mode]

m = max(d, key=d.get)     #'a' 最大值所在键
```

#### 字典内置函数&方法

| 序号 |                          函数及描述                          |
| :--: | :----------------------------------------------------------: |
|  1   |           len(dict) 计算字典元素个数，即键的总数。           |
|  2   |          str(dict) 输出字典，以可打印的字符串表示。          |
|  3   | type(variable) 返回输入的变量类型，如果变量是字典就返回字典类型。 |

| 序号 |                          函数及描述                          |
| :--: | :----------------------------------------------------------: |
|  1   | [radiansdict.clear()](https://www.nowcoder.com/tutorial/10005/eb4ba86a2c444720b6e46619e3c9e25f) 删除字典内所有元素 |
|  2   | [radiansdict.copy()](https://www.nowcoder.com/tutorial/10005/d77c4ad27bab497985a8ceae1f0174d8) 返回一个字典的浅复制 |
|  3   | [radiansdict.fromkeys()](https://www.nowcoder.com/tutorial/10005/e1450db03d454ead8fcff4ae5783fbc1) 创建一个新字典，以序列seq中元素做字典的键，val为字典所有键对应的初始值 |
|  4   | [radiansdict.get(key, default=None)](https://www.nowcoder.com/tutorial/10005/2de7f74b36f64ecd8f7c53892a8b1bc4) 返回指定键的值，如果值不在字典中返回default值 |
|  5   | [key in dict](https://www.nowcoder.com/tutorial/10005/15d46a706db34dfa8f5d3713ad1c1790) 如果键在字典dict里返回true，否则返回false |
|  6   | [radiansdict.items()](https://www.nowcoder.com/tutorial/10005/8482421fa09c4acf8e1e031f6f450bd9) 以列表返回可遍历的(键, 值) 元组数组 |
|  7   | [radiansdict.keys()](https://www.nowcoder.com/tutorial/10005/68714616b1e649be8b6a980ff83d80ad) 返回一个迭代器，可以使用 list() 来转换为列表 |
|  8   | [radiansdict.setdefault(key, default=None)](https://www.nowcoder.com/tutorial/10005/45a90943b49947c39f97070f86e6d2cd) 和get()类似, 但如果键不存在于字典中，将会添加键并将值设为default |
|  9   | [radiansdict.update(dict2)](https://www.nowcoder.com/tutorial/10005/663162addca14275bcb5ea2ef5e9ba43) 把字典dict2的键/值对更新到dict里 |
|  10  | [radiansdict.values()](https://www.nowcoder.com/tutorial/10005/b99c0357611642e4a89bdafa33a48e21) 返回一个迭代器，可以使用 list() 来转换为列表 |
|  11  | pop(key[,default\])](https://www.nowcoder.com/tutorial/10005/c9ecb28a38c54ba39917d021097a15af) 删除字典给定键 key 所对应的值，返回值为被删除的值。key值必须给出。 否则，返回default值。 |
|  12  | [popitem()](https://www.nowcoder.com/tutorial/10005/b9cfe665ceab46fda7be06da2e111996) 随机返回并删除字典中的最后一对键和值。 |



### 六，集合

集合（set）是一个无序的不重复元素序列。

可以使用大括号 **{ }** 或者 **set()** 函数创建集合，注意：创建一个空集合必须用 **set()** 而不是 **{ }**，因为 **{ }** 是用来创建一个空字典。

|                             方法                             |                             描述                             |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| [add()](https://www.nowcoder.com/tutorial/10005/81b8f564e25849a3b5281dfa2e21ad9b) |                        为集合添加元素                        |
| [clear()](https://www.nowcoder.com/tutorial/10005/a60ec94287fe468c831a76e943fe9306) |                     移除集合中的所有元素                     |
| [copy()](https://www.nowcoder.com/tutorial/10005/bbb1733f797b4334a65e8c1c0a0df100) |                         拷贝一个集合                         |
| [difference()](https://www.nowcoder.com/tutorial/10005/40d1d4ff2b7748288876219fd1445bb7) |                      返回多个集合的差集                      |
| [difference_update()](https://www.nowcoder.com/tutorial/10005/bffd4e290e9044038cb4667bb631a457) |         移除集合中的元素，该元素在指定的集合也存在。         |
| [discard()](https://www.nowcoder.com/tutorial/10005/2ac6397f3e074d08a20d730753e19c74) |                     删除集合中指定的元素                     |
| [intersection()](https://www.nowcoder.com/tutorial/10005/76b9a595302b4f2493f15a8372352c51) |                        返回集合的交集                        |
| [intersection_update()](https://www.nowcoder.com/tutorial/10005/39bbe5515bab4a97a5dd4521b0cc3be3) |                       返回集合的交集。                       |
| [isdisjoint()](https://www.nowcoder.com/tutorial/10005/8da683581ca84cf4b89c8e99e77eaa0e) | 判断两个集合是否包含相同的元素，如果没有返回 True，否则返回 False。 |
| [issubset()](https://www.nowcoder.com/tutorial/10005/89218e51863044ccb31fcf153f2c48c0) |           判断指定集合是否为该方法参数集合的子集。           |
| [issuperset()](https://www.nowcoder.com/tutorial/10005/4e6dea594bca42e8b68e9c50d5064580) |           判断该方法的参数集合是否为指定集合的子集           |
| [pop()](https://www.nowcoder.com/tutorial/10005/33ab4fa52a454e69abb12872d6b4d2db) |                         随机移除元素                         |
| [remove()](https://www.nowcoder.com/tutorial/10005/bb7d7a8463194580be6cfa25841f1f6f) |                         移除指定元素                         |
| [symmetric_difference()](https://www.nowcoder.com/tutorial/10005/fda5fe12050f468eb032742bcb76d635) |               返回两个集合中不重复的元素集合。               |
| [symmetric_difference_update()](https://www.nowcoder.com/tutorial/10005/067f9a47a24a4aefbc367346feb25302) | 移除当前集合中在另外一个指定集合相同的元素，并将另外一个指定集合中不同的元素插入到当前集合中。 |
| [union()](https://www.nowcoder.com/tutorial/10005/989cc9efe9d042378b4f278229743867) |                      返回两个集合的并集                      |
| [update()](https://www.nowcoder.com/tutorial/10005/a97dfc672bb94f8f92f5b4c7878b4611) |                        给集合添加元素                        |