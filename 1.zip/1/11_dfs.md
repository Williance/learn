DFS 与 BFS 在寻找路径最不同的一点是，DFS 是一条路走到黑，它适合用于 「是否存在一条路径」，而 BFS 是影分身，每次影分身都会在原基础上走一步，适合用于 「是否存在一条最短路径」。



#### [79. 单词搜索](https://leetcode-cn.com/problems/word-search/)

#### [剑指 Offer 12. 矩阵中的路径](https://leetcode-cn.com/problems/ju-zhen-zhong-de-lu-jing-lcof/)

给定一个 `m x n` 二维字符网格 `board` 和一个字符串单词 `word` 。如果 `word` 存在于网格中，返回 `true` ；否则，返回 `false` 。

单词必须按照字母顺序，通过相邻的单元格内的字母构成，其中“相邻”单元格是那些水平相邻或垂直相邻的单元格。同一个单元格内的字母不允许被重复使用。

![img](https://assets.leetcode.com/uploads/2020/11/04/word2.jpg)

```
示例 1：
输入：board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
输出：true

示例 2：
输入：board = [["a","b"],["c","d"]], word = "abcd"
输出：false
```

```python
#dfs+回溯（去重）
class Solution:
    def exist(self, board: List[List[str]], word: str) -> bool:
        def dfs(i, j, k):
            # 用来判断程序是否越界，还有第一个字母是否匹配，第一个都不匹配直接返回False
            if not 0 <= i < len(board) or not 0 <= j < len(board[0]) or board[i][j] != word[k]:  
                return False
            # 当程序跑到word的最后一个字母时，这时无需再dfs，直接返回True
            if k == len(word) - 1: 
                return True
            # 把访问过的字母标记为空，这样可以避免程序多次访问同一元素
            board[i][j] = ""
            # 剪枝顺序：下、上、右、左
            res = dfs(i + 1, j, k + 1) or dfs(i - 1, j, k + 1) or dfs(i, j + 1, k + 1) or dfs(i, j - 1, k + 1)
            # 一趟dfs结束后把原来设的空改回来，以免影响后面的dfs遍历使用
            board[i][j] = word[k]
            return res 
        # 一个一个字母来尝试，每一次尝试都是dfs遍历成功的一种可能性
        for i in range(len(board)):
            for j in range(len(board[0])):
                if dfs(i, j, 0): 
                    return True
        # 遍历完成，仍没有成功的路径，返回False
        return False
```



#### [1219. 黄金矿工](https://leetcode-cn.com/problems/path-with-maximum-gold/)

你要开发一座金矿，地质勘测学家已经探明了这座金矿中的资源分布，并用大小为 m * n 的网格 grid 进行了标注。每个单元格中的整数就表示这一单元格中的黄金数量；如果该单元格是空的，那么就是 0。

为了使收益最大化，矿工需要按以下规则来开采黄金：

+ 每当矿工进入一个单元，就会收集该单元格中的所有黄金。
+ 矿工每次可以从当前位置向上下左右四个方向走。
  每个单元格只能被开采（进入）一次。
+ 不得开采（进入）黄金数目为 0 的单元格。
+ 矿工可以从网格中 任意一个 有黄金的单元格出发或者是停止。

```
输入：grid = [[0,6,0],[5,8,7],[0,9,0]]
输出：24
解释：
[[0,6,0],
 [5,8,7],
 [0,9,0]]
一种收集最多黄金的路线是：9 -> 8 -> 7。
```

```python
class Solution:
    def getMaximumGold(self, grid: List[List[int]]) -> int:
        R, C = len(grid), len(grid[0])      
        
        def dfs_backtrace(r: int, c: int) -> int:
            if not (0 <= r < R and 0 <= c < C) or grid[r][c] == 0:
                return 0
            tmp = grid[r][c]                #开始设计回溯
            grid[r][c] = 0                  #标记visited，在gird中置0

            nxt_sum = 0
            for nr, nc in ((r-1, c), (r+1, c), (r, c-1), (r, c+1)):
                nxt_sum = max(nxt_sum, dfs_backtrace(nr, nc))
            
            grid[r][c] = tmp                #回溯
            return tmp + nxt_sum            #返回从该点出发能得到的最大值
        
        res = 0
        for r in range(R):
            for c in range(C):
                if grid[r][c] != 0:
                    res = max(res, dfs_backtrace(r, c))
        return res
```



[329. 矩阵中的最长递增路径](https://leetcode-cn.com/problems/longest-increasing-path-in-a-matrix/)

#### [剑指 Offer II 112. 最长递增路径](https://leetcode-cn.com/problems/fpTFWP/)

给定一个 `m x n` 整数矩阵 `matrix` ，找出其中 **最长递增路径** 的长度。

对于每个单元格，你可以往上，下，左，右四个方向移动。 你 **不能** 在 **对角线** 方向上移动或移动到 **边界外**（即不允许环绕）。

![img](https://assets.leetcode.com/uploads/2021/01/05/grid1.jpg)

```
输入：matrix = [[9,9,4],[6,6,8],[2,1,1]]
输出：4 
解释：最长递增路径为 [1, 2, 6, 9]。
```

![img](https://assets.leetcode.com/uploads/2021/01/27/tmp-grid.jpg)

```
输入：matrix = [[3,4,5],[3,2,6],[2,2,1]]
输出：4 
解释：最长递增路径是 [3, 4, 5, 6]。注意不允许在对角线方向上移动。
```

```
示例 3：
输入：matrix = [[1]]
输出：1
```

```python
class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        def dfs(x,y):
            if memo[x][y] !=0 :
                return memo[x][y]
            memo[x][y] += 1
            for dx,dy in [(-1,0),(1,0),(0,1),(0,-1)]:
                xx,yy = x+dx,y+dy
                if 0<=xx<m and 0<=yy<n and matrix[xx][yy]>matrix[x][y]:
                    memo[x][y] = max(memo[x][y],dfs(xx,yy)+1)
            return memo[x][y]

        res,m,n = 0,len(matrix),len(matrix[0])
        memo = [[0]*n for _ in range(m)]
        for i in range(m):
            for j in range(n):
                res = max(res,dfs(i,j))
        return res

class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        @lru_cache(None)
        def dfs(x,y):
            ans = 1
            for dx,dy in [(-1,0),(1,0),(0,1),(0,-1)]:
                xx,yy = x+dx,y+dy
                if 0<=xx<m and 0<=yy<n and matrix[xx][yy]>matrix[x][y]:
                    ans = max(ans,dfs(xx,yy)+1)
            return ans

        res,m,n = 0,len(matrix),len(matrix[0])
        for i in range(m):
            for j in range(n):
                res = max(res,dfs(i,j))
        return res
```



#### [剑指 Offer 17. 打印从1到最大的n位数](https://leetcode-cn.com/problems/da-yin-cong-1dao-zui-da-de-nwei-shu-lcof/)

输入数字 `n`，按顺序打印出从 1 到最大的 n 位十进制数。比如输入 3，则打印出 1、2、3 一直到最大的 3 位数 999。

```python
class Solution:
    def printNumbers(self, n: int) -> List[int]:
        return list(range(1, 10 ** n))
```

<img src="https://pic.leetcode-cn.com/83f4b5930ddc1d42b05c724ea2950ee7f00427b11150c86b45bd88405f8c7c87-Picture1.png" alt="Picture1.png" style="zoom: 33%;" />

```python
class Solution:
    def printNumbers(self, n: int) -> [int]:
        def dfs(x):
            if x == n:                          #结束条件
                tmp = ''.join(num).lstrip('0')    #去掉左边的0
                if tmp != '':
                    res.append(int(tmp))
                return
            for i in range(10):
                num[x] = str(i)
                dfs(x+1)
        num = ['0']*n 
        res = []
        dfs(0)
        return res
```



#### [397. 整数替换](https://leetcode-cn.com/problems/integer-replacement/)

给定一个正整数 `n` ，你可以做如下操作：

1. 如果 `n` 是偶数，则用 `n / 2`替换 `n` 。
2. 如果 `n` 是奇数，则可以用 `n + 1`或`n - 1`替换 `n` 。

`n` 变为 `1` 所需的最小替换次数是多少？

```
输入：n = 7
输出：4
解释：7 -> 8 -> 4 -> 2 -> 1
或 7 -> 6 -> 3 -> 2 -> 1
```

```python
class Solution:
    def integerReplacement(self, n: int) -> int:
        meno = {}  #利用字典进行记忆缓存
        def dfs(n):
            if n in meno:
                return meno.get(n)
            if n == 1:
                return 0
            if n%2 == 0:
                meno[n] = dfs(n/2)+1
            else:
                meno[n] = min(dfs(n+1),dfs(n-1))+1
            return meno[n]
        return dfs(n)
```



#### [1575. 统计所有可行路径](https://leetcode-cn.com/problems/count-all-possible-routes/)

给你一个 **互不相同** 的整数数组，其中 `locations[i]` 表示第 `i` 个城市的位置。同时给你 `start`，`finish` 和 `fuel` 分别表示出发城市、目的地城市和你初始拥有的汽油总量

每一步中，如果你在城市 `i` ，你可以选择任意一个城市 `j` ，满足  `j != i` 且 `0 <= j < locations.length` ，并移动到城市 `j` 。从城市 `i` 移动到 `j` 消耗的汽油量为 `|locations[i] - locations[j]|`，`|x|` 表示 `x` 的绝对值。

请注意， `fuel` 任何时刻都 **不能** 为负，且你 **可以** 经过任意城市超过一次（包括 `start` 和 `finish` ）。

请你返回从 `start` 到 `finish` 所有可能路径的数目。

由于答案可能很大， 请将它对 `10^9 + 7` 取余后返回。

```
示例 1：
输入：locations = [2,3,6,8,4], start = 1, finish = 3, fuel = 5
输出：4
解释：以下为所有可能路径，每一条都用了 5 单位的汽油：
1 -> 3
1 -> 2 -> 3
1 -> 4 -> 3
1 -> 4 -> 2 -> 3

示例 2：
输入：locations = [4,3,1], start = 1, finish = 0, fuel = 6
输出：5
解释：以下为所有可能的路径：
1 -> 0，使用汽油量为 fuel = 1
1 -> 2 -> 0，使用汽油量为 fuel = 5
1 -> 2 -> 1 -> 0，使用汽油量为 fuel = 5
1 -> 0 -> 1 -> 0，使用汽油量为 fuel = 3
1 -> 0 -> 1 -> 0 -> 1 -> 0，使用汽油量为 fuel = 5
```

```python
#dfs：预处理 记忆化缓存
class Solution:
    def countRoutes(self, locations: List[int], start: int, finish: int, fuel: int) -> int:
        n = len(locations)
        mod = 10 ** 9 + 7

        # 预处理: 计算两两城市间的距离, 否则的话, 一对城市间的距离会重复计算多遍
        D = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i):
                D[i][j] = D[j][i] = abs(locations[i] - locations[j])

        @cache
        def dfs(idx, cost):
            ans = 0
            #油量不为0 or 在某个位置idx出发，不能一步到达目的地finish，将永远无法到达目的地。
            if cost > fuel or (fuel - cost) < D[idx][finish]: 
                return ans
            if idx == finish:
                ans += 1
            for i in range(len(locations)):
                if idx != i:
                    ans = (ans + dfs(i, cost + D[i][idx])) % mod
            return ans

        return dfs(start, 0)
```

```python
#dp:  f[i][j]代表从位置i出发，当前剩余油量为j的前提下，到达目的地的路径数量。
class Solution:
    def countRoutes(self, locations: List[int], start: int, finish: int, fuel: int) -> int:
        n = len(locations)
        dp = [[0] * (fuel + 1) for _ in range(n)]
        for i in range(fuel + 1): #初始化
            dp[finish][i] = 1
        for j in range(fuel + 1): #注意遍历顺序：从小到大
            for i in range(n):
                for k in range(n):
                    cur = abs(locations[i] - locations[k])
                    if i != k and j >= cur:
                        dp[i][j] += dp[k][j - cur]
        return dp[start][fuel] % (10 ** 9 + 7)
```



#### HJ77火车进站

给定一个正整数N代表火车数量，0<N<10，接下来输入火车入站的序列，一共N辆火车，每辆火车以数字1-9编号，火车站只有一个方向进出，同时停靠在火车站的列车中，只有后进站的出站了，先进站的才能出站。要求输出所有火车出站的方案，以字典序排序输出。

输入描述：

第一行输入一个正整数N（0 < N <= 10），第二行包括N个正整数，范围为1到10。

输出描述：

输出以字典序从小到大排序的火车出站序列号，每个编号以空格隔开，每个输出序列换行，具体见sample。

```
输入：
3
1 2 3
输出：
1 2 3
1 3 2
2 1 3
2 3 1
3 2 1
```

```python
# 解题思路：使用三个变量，分别表示待进站火车、待出站火车、出站火车。
# 每次作业（只操作一辆车）有两种情况发生，一种是进站作业，一种是出站作业
# 将作业结果当作参数递归下去，递归结束标志是待进站火车和待出站火车都没有了
class Solution:
    def __init__(self):
        self.ans = []

    def dfs(self, wait, stack, leave):
        if len(wait) == 0 and len(stack) == 0: #都离开
            self.ans.append(leave)
        #进行切片操作是 副本，不用回溯
        if len(wait) > 0:  #进站 入栈
            self.dfs(wait[1:], stack + [wait[0]], leave[:])

        if len(stack) > 0:  #出站 出栈
            self.dfs(wait[:], stack[:-1], leave + [stack[-1]])
        return self.ans

# 处理一些输入输出
if __name__ == '__main__':
    while True:
        try:
            n = input()
            nums = input().split()
            sol = Solution()
            ret = sol.dfs(nums, [], [])
            for line in sorted(ret):
                print(" ".join(line))
        except:
            break
```
