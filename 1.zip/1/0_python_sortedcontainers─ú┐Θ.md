#### sortedcontainers

http://www.grantjenks.com/docs/sortedcontainers/introduction.html



#### [Sorted List](http://www.grantjenks.com/docs/sortedcontainers/introduction.html#id2) 排序列表

```python
from sortedcontainers import SortedList
sl = SortedList()

sl.update([5, 1, 3, 4, 2])   # SortedList([1, 2, 3, 4, 5])
sl.add(0)                    # SortedList([0, 1, 2, 3, 4, 5])
sl.remove(0)
sl.discard(1)                # SortedList([2, 3, 4, 5]) --value
del sl[1]                    # SortedList([2, 4, 5])    --index
sl.pop()                     # 5
sl.clear()                   # del all values
```

```python
sl = SortedList('abbcccddddeeeee')

'f' in sl              # False
sl.count('e')          # 5
sl.index('c')          # 3
sl.bisect_left('d')    # 6   二分左
sl.bisect_right('d')   # 10  二分右
sl[3]                  # 'c'
sl[6:10]               # ['d', 'd', 'd', 'd']
```

**注意**：

1.默认降序

2.添加元素的方式: (1)add   (2)+=  (3)*=



#### [Sorted-key List](http://www.grantjenks.com/docs/sortedcontainers/introduction.html#id3) 排序列表+key

```python
from operator import neg #负
from sortedcontainers import SortedKeyList

skl = SortedKeyList([1, 2, 3, 4, 5], key=neg) # SortedKeyList([5, 4, 3, 2, 1], key=<built-in function neg>)
skl.bisect_key_left(-4.5)                     # 1
skl.bisect_key_right(-1.5)                    # 4
list(skl.irange_key(-4.5, -1.5))              # [4, 3, 2]
```

**注意：**

1.key为排序规则，更加灵活的方式



#### [Sorted Dict](http://www.grantjenks.com/docs/sortedcontainers/introduction.html#id5) 排序字典

```python
from sortedcontainers import SortedDict
sd = SortedDict()
sd = SortedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})

sd.bisect_right('b')  # 2 二分右

del sd['d']
sd.pop('c')           # 3         --key
sd.popitem(index=-1)  # ('e', 5)  --item
sd.peekitem(index=-1) # ('b', 2)
```

```python
#key的排序规则
from operator import neg
SortedDict(neg, {1: 'a', 2: 'b'})  # SortedDict(<built-in function neg>, {2: 'b', 1: 'a'})
```

保留字典特性



#### [Sorted Set](http://www.grantjenks.com/docs/sortedcontainers/introduction.html#id6) 排序集合

```python
from sortedcontainers import SortedSet
ss = SortedSet()
ss = SortedSet([1, 2, 3], key=neg)       # SortedSet([3, 2, 1], key=<built-in function neg>)
ss.bisect(2)                             # 2 二分右
```

保留集合特性



