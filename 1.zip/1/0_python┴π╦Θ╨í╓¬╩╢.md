#### 1.Python标准库模块之heapq

#### 2.sorted() 函数

见排序1



#### 3.切片 X[start​ ​ : end : ​span]

+ a[::-1] 取反
+ a[:-1]  除最后一位元素的切片 （a[-1]: 最后一位元素）--左开右闭
+ a[1:]   从下标1开始的切片

注意：进行切片操作后得到的是一个**全新的列表**，是原列表的一个副本

​			不要**同时**指定（start  : end ）和（span），分开操作，先切片在步进



#### 4.格式化字符串f-string（优先选择）

f-string，亦称为格式化字符串常量（formatted string literals），是Python3.6新引入的一种字符串格式化方法，主要目的是使格式化字符串的操作更加简便。

与具有恒定值的其它字符串常量不同，格式化字符串实际上是运行时运算求值的表达式。

<img src="C:\Users\DELL\Desktop\算法学习\f_string.png" alt="f_string" style="zoom:50%;" />

```python
f'str{exstr}'  # exstr为替换的字段

a = 123.4559   
b = f'{a:.2f}'  #‘123.46’ 格式化

pre = 2 #位数 --表达式可以出现在格式说明符中
b1 = f'{a:.{pre}f}' #‘123.46’ 格式化

c = f'{4*5}'    #'20'     表达式 eval（）
```

https://blog.csdn.net/sunxb10/article/details/81036693



#### 5.join

```
str.join(strseq) #str 连接符；seq 字符串迭代类型
```



#### 6.str.lstrip([chars])

+ 参数
  chars --指定截取的字符。
+ 返回值
  返回截掉字符串左边的空格(默认)或指定字符后生成的新字符串。



#### 7.ord() +  chr() 

ord() 函数是 chr() 函数（对于8位的ASCII字符串）或 unichr() 函数（对于Unicode对象）的配对函数，它以一个字符（长度为1的字符串）作为参数，返回对应的 ASCII 数值，或者 Unicode 数值

```python
ia = ord('a') #97
chr(ia)       #'a'
ord('b')-ord('a') #字符的数学运算
```



#### 8.os.walk()

https://zhuanlan.zhihu.com/p/149824829

![preview](https://pic4.zhimg.com/v2-4fafa331625664ad3babdb7e2b930887_r.jpg)

https://zhuanlan.zhihu.com/p/200995093



#### 9. is ==的区别

1. == 是比较两个对象的内容是否相等，即两个对象的“值“”是否相等，不管两者在内存中的引用地址是否一样。
2. is 比较的是两个实例对象是不是完全相同，它们是不是同一个对象，占用的内存地址是否相同。即is比较两个条件：内容相同以及内存中地址相同



#### 10.链式比较

```python
80 < score < 90  #score > 80 and score < 90
False == False == True  #False == False and False  == True
```



#### 11.三目运算

```python
if age > 18:
	type = "adult"
else:
	type = "teenager"
    
type = "adult" if age > 18 else "teenager"
```



#### 12.enumerate() 函数

enumerate() 函数用于将一个可遍历的数据对象(如列表、元组或字符串)组合为一个索引序列，同时列出数据和数据下标。

--enumerate(sequence, [start=0])

```python
seasons = ['Spring', 'Summer', 'Fall', 'Winter']
list(enumerate(seasons, start=1))       # 下标从 1 开始
#[(1, 'Spring'), (2, 'Summer'), (3, 'Fall'), (4, 'Winter')]

seq = ['one', 'two', 'three']
for i, element in enumerate(seq):
	print i, element

#0 one
#1 two
#2 three
```



#### 13.in 函数

+ in	       如果在指定的序列中找到值返回 True，否则返回 False。	x 在 y 序列中 , 如果 x 在 y 序列中返回 True。
+ not in	如果在指定的序列中没有找到值返回 True，否则返回 False。	x 不在 y 序列中 , 如果 x 不在 y 序列中返回 True。
+ is	       是判断两个标识符是不是引用自一个对象	x is y, 类似 id(x) == id(y) , 如果引用的是同一个对象则返回 True，否则返回 False
+ is not	是判断两个标识符是不是引用自不同对象	x is not y ， 类似 id(a) != id(b)。如果引用的不是同一个对象则返回结果 True，否则返回 False。



#### 14.倒序遍历

```python
for i in reversed(range(0,10)):
    print(i,end = ' ')
```



#### 15.zip的妙用

+ 矩阵旋转

```python
matrix = [[1,2,3],[4,5,6],[7,8,9]]
leftmatrix = [list(tup)[::-1] for tup in zip(*matrix)] #顺时针90度
rightmatrix = list(zip(*matrix))[::-1]                 #逆时针90度

print(leftmatrix)
#[[7, 4, 1], [8, 5, 2], [9, 6, 3]]
print(rightmatrix)
#[(3, 6, 9), (2, 5, 8), (1, 4, 7)]

#zip(*matrix)
#((1,4,7),(2,5,8),(3,6,9))
```

+ 等长序列 --元素一一比较的情景

  eg：只有一个元素差异，n

```python
diff = [(a, b) for a, b in zip(s, goal) if a != b] 
```



#### 16.除法 向上向下取整

```python
#向下
a // b

#向上
(a + b - 1) // b

import math
math.ceil(a / b)
```



#### 17.[python中/和//的区别](https://www.cnblogs.com/xingxyx/p/11811552.html)

 “ / ” 为浮点数除法，返回浮点结果

“ // ” 表示整数除法，返回不大于结果的一个最大整数



#### 18.正负无穷

```python
float('inf')  #min 初始化
float('-inf') #max
```



#### 19.缓存修饰器 --dfs/bfs

```
@cache
@lru_cache(None)
```

https://docs.python.org/zh-cn/3/library/functools.html?highlight=functools



#### 20.迭代器模块itertools  --子集，组合，全排列

**Combinatoric iterators:**

| Iterator                                                     | Arguments          | Results                                                      |
| :----------------------------------------------------------- | :----------------- | :----------------------------------------------------------- |
| [`product()`](https://docs.python.org/3/library/itertools.html#itertools.product) | p, q, … [repeat=1] | cartesian product, equivalent to a nested for-loop           |
| [`permutations()`](https://docs.python.org/3/library/itertools.html#itertools.permutations) | p[, r]             | r-length tuples, all possible orderings, no repeated elements |
| [`combinations()`](https://docs.python.org/3/library/itertools.html#itertools.combinations) | p, r               | r-length tuples, in sorted order, no repeated elements       |
| [`combinations_with_replacement()`](https://docs.python.org/3/library/itertools.html#itertools.combinations_with_replacement) | p, r               | r-length tuples, in sorted order, with repeated elements     |

```python
from itertools import *
```

| Examples                                   | Results                                           |                |
| :----------------------------------------- | :------------------------------------------------ | -------------- |
| `product('ABCD', repeat=2)`                | `AA AB AC AD BA BB BC BD CA CB CC CD DA DB DC DD` |                |
| `product('ABCD', 'xy')`                    | ` Ax Ay Bx By Cx Cy Dx Dy`                        | 组合           |
| `permutations('ABCD', 2)`                  | `AB AC AD BA BC BD CA CB CD DA DB DC`             | 全排列         |
| `combinations('ABCD', 2)`                  | `AB AC AD BC BD CD`                               | 组合--定长子集 |
| ` combinations(range(4), 3)`               | ` 012 013 023 123`                                | 组合           |
| `combinations_with_replacement('ABCD', 2)` | `AA AB AC AD BB BC BD CC CD DD`                   |                |

https://docs.python.org/3/library/itertools.html



#### 21.排序的容器模块 sortedcontainers --线段树

http://www.grantjenks.com/docs/sortedcontainers/introduction.html

见排序1



#### 22.二分法模块 bisect --二分法

见二分法



#### 23.all函数

```
all(iterable)
```

如果iterable的所有元素不为0、''、False或者iterable为空，all(iterable)返回True，否则返回False；

**注意：**空元组、空列表返回值为True



#### 24.pow()  --快速幂+取mod

```
pow(x, y[, z])
```

函数是计算x的y次方，如果z在存在，则再对结果进行取模，其结果等效于pow(x,y) %z

**注意：**pow() 通过内置的方法直接调用，内置方法会把参数作为整型，而 math 模块则会把参数转换为 float。



#### 25.eval()

```
eval(expression, globals=None, locals=None)
```

- expression -- 表达式。
- globals -- 变量作用域，全局命名空间，如果被提供，则必须是一个字典对象。
- locals -- 变量作用域，局部命名空间，如果被提供，可以是任何映射对象。

```python
x = 10
def func():
    y = 20
    a = eval('x + y')
    print('a: ', a)   #30
    b = eval('x + y', {'x': 1, 'y': 2})
    print('b: ', b)   #3
    c = eval('x + y', {'x': 1, 'y': 2}, {'y': 3, 'z': 4})
    print('c: ', c)   #4
    d = eval('print(x, y)') #10 20
    print('d: ', d)   #None
func()
```

***对输出结果的解释：***

- 对于变量a，eval函数的globals和locals参数都被忽略了，因此变量x和变量y都取得的是eval函数被调用环境下的作用域中的变量值，即：x = 10, y = 20，a = x + y = 30
- 对于变量b，eval函数只提供了globals参数而忽略了locals参数，因此locals会取globals参数的值，即：x = 1, y = 2，b = x + y = 3
- 对于变量c，eval函数的globals参数和locals都被提供了，那么eval函数会先从全部作用域globals中找到变量x, 从局部作用域locals中找到变量y，即：x = 1, y = 3, c = x + y = 4
- 对于变量d，因为print()函数不是一个计算表达式，没有计算结果，因此返回值为None



#### 26.max（）

```
max(iterable, *[, key, default])
max(arg1, arg2, *args[, key])
```

默认数值型参数，取值大者；字符型参数，取字母表排序靠后者。

key---可做为一个函数，用来指定取最大值的方法。

default---用来指定最大值不存在时返回的默认值。

arg1---字符型参数/数值型参数，默认数值型

```python
d = {'b':1, 'a':3, 'c':2}
m = max(d, key=d.get)     #'a' 最大值所在键
s = ['ab','abcd','a']
ms = max(s,key=len)       #'abcd' 返回最长字符串
```



#### 27.maketrans()方法

用于创建字符映射的转换表

```
str.maketrans(dict)
str.maketrans(instr, outstr)
```

```python
d = {'a':'1','b':'2','c':'3','d':'4','e':'5','s':'6'}
trantab = str.maketrans(d)
st='just do it'
st.translate(trantab) #ju6t 4o it

x = 'abcdes'
y = '123456'
trantab = str.maketrans(x,y)
```



#### 28.区间左右移

```python
#[start,end] 移k 区间长度l i 
start+(i-start+k)%l #左移
start+(i-start-k)%l #右移
```



#### 29.all() 函数

all() 函数用于判断给定的可迭代参数 iterable 中的所有元素是否都为 TRUE，如果是返回 True，否则返回 False。

元素除了是 0、空、None、False 外都算 True。注：iter本来为空，即空元组、空列表，返回值为True

```
all(iterable)
```

