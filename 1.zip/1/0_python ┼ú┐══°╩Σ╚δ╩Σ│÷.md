### python 牛客网输入输出



#### 输入

+ 单行输入

```python
while True:
    try:
        
        #单行输入
        n = int(input()) #'22' --22
        n,m = map(int,input().split()) #'22 3' --22,3  int/str
        c = list(map(int,input().split())) #'1 2 3 4 5' --[1,2,3,4,5]

    except:
        break
```

+ 多行输入

  + 行数n 已经知道，eg：

    3 --行数

    1

    2

    3

  ```python
  while True:
      try:
  
          res = []
          n = int(input())#行数
          for _ in range(n):
              s = input()  #int（input()）类型转换
              res.append(s)
  
      except:
          break
  ```

  + **行数n未知** 

    1 2 3 4

    3 5 6 8 9

    --[['1', '2', '3', '4'], ['3', '5', '6', '8', '9']]  （res）

```python
res = []
while True:
    try:
        s = input()
        # res.append(list(map(int, s.split(' '))))
        res.append(list(map(str, s.split()))) #int/list
        
    except:
        break
```

+ 列表类型str

```python
s = '[[1,2,5],[1,3,5],[4,2,10],[2,5,5],[3,4,10],[3,7,10],[4,7,5],[5,6,5],[6,7,5]]'
s = '[1, 1, 1, 1, -4, 1]'
imat = eval(s) #转化为 int 列表
```



#### 输出

+ 单行输出

  一般将 字符串str-list  使用  .join 函数连接

  ```python
  a = [1,2,3,4,5]  #int-list
  b = list(map(str,a))   #str-list
  c = ' '.join(b)  #使用空格连接
  print(c)
  ```

  ```python
  #更改结束标志
  #ptint的结束标志默认为换行，不过可以通过print(a,end=" " )进行更改
  res = [1,2,3,4]
  for r in res:
  	print(r,end=' ')
  ```

  

+ 多行输出

```python
res = [1,2,3,4]
for r in res:      #for循环
	print(r)
```

