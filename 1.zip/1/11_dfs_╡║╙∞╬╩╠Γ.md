### 1.基本概念

**网格问题**是由m×n 个小方格组成一个网格，每个小方格与其上下左右四个方格认为是相邻的，要在这样的网格上进行某种搜索。**岛屿问题**是一类典型的网格问题。每个格子中的数字可能是 0 或者 1。我们把数字为 0 的格子看成海洋格子，数字为 1 的格子看成陆地格子，这样相邻的陆地格子就连接成一个岛屿。

<img src="https://pic.leetcode-cn.com/c36f9ee4aa60007f02ff4298bc355fd6160aa2b0d628c3607c9281ce864b75a2.jpg" alt="岛屿问题示例" style="zoom:50%;" />

### 2.DFS的基本架构

+ **访问相邻结点**--上下左右

  ```python
  dir = [(-1,0),(1,0),(0,1),(0,-1)]
  for dx,dy in dir:
  	xx,yy = x+dx,y+dy
  	dfs(grid,xx,yy)
  ```

+ **判断 base case**--出边界（先污染后治理）

  ```python
  m,n = len(grid),len(grid[0])
  if not 0<=xx<m or not 0<=yy<n:
  	return
  ```

+ #### **避免重复遍历**

  网格结构本质上是一个「图」，我们可以把每个格子看成图中的结点，每个结点有向上下左右的四条边。在图中遍历时，自然可能遇到重复遍历结点。

  + 解决方式：标记已经遍历过的格子
  + 参考方式：每**走过**一个陆地格子，就把格子的值**改为** 2
  + 好处：区分「海洋格子」和「已遍历过的陆地格子」

  <img src="https://pic.leetcode-cn.com/20fe202fb5e5fc5048e140c29310c1bcbb17661860d2441e8a3feb1236a2e44d.gif" alt="标记已遍历的格子" style="zoom:50%;" />

### 3.基本问题

#### [200. 岛屿数量](https://leetcode-cn.com/problems/number-of-islands/)

给你一个由 `'1'`（陆地）和 `'0'`（水）组成的的二维网格，请你计算网格中岛屿的数量。

岛屿总是被水包围，并且每座岛屿只能由水平方向和/或竖直方向上相邻的陆地连接形成。

此外，你可以假设该网格的四条边均被水包围。

```
示例 1：
输入：grid = [
  ["1","1","1","1","0"],
  ["1","1","0","1","0"],
  ["1","1","0","0","0"],
  ["0","0","0","0","0"]
]
输出：1

示例 2：
输入：grid = [
  ["1","1","0","0","0"],
  ["1","1","0","0","0"],
  ["0","0","1","0","0"],
  ["0","0","0","1","1"]
]
输出：3
```

```python
class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        dir = [(-1,0),(1,0),(0,-1),(0,1)]
        m,n = len(grid),len(grid[0])
        ans = 0

        def dfs(grid,x,y):
            if not 0<=x<m or not 0<=y<n:
                return
            if grid[x][y] != '1':
                return
            grid[x][y] = '2'
            for dx,dy in dir:
                xx,yy = x+dx,y+dy
                dfs(grid,xx,yy)

        for i in range(m):
            for j in range(n):
                if grid[i][j] == '1':
                    ans += 1
                    dfs(grid,i,j)
        
        return ans
```



#### [剑指 Offer II 105. 岛屿的最大面积](https://leetcode-cn.com/problems/ZL6zAn/)

#### [695. 岛屿的最大面积](https://leetcode-cn.com/problems/max-area-of-island/)

给你一个大小为 `m x n` 的二进制矩阵 `grid` 。

**岛屿** 是由一些相邻的 `1` (代表土地) 构成的组合，这里的「相邻」要求两个 `1` 必须在 **水平或者竖直的四个方向上** 相邻。你可以假设 `grid` 的四个边缘都被 `0`（代表水）包围着。

岛屿的面积是岛上值为 `1` 的单元格的数目。

计算并返回 `grid` 中最大的岛屿面积。如果没有岛屿，则返回面积为 `0` 。

<img src="https://assets.leetcode.com/uploads/2021/05/01/maxarea1-grid.jpg" alt="img" style="zoom: 33%;" />

```
示例 1：
输入：grid = [[0,0,1,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,1,1,0,1,0,0,0,0,0,0,0,0],[0,1,0,0,1,1,0,0,1,0,1,0,0],[0,1,0,0,1,1,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,1,1,0,0,0,0]]
输出：6
解释：答案不应该是 11 ，因为岛屿只能包含水平或垂直这四个方向上的 1 。

示例 2：
输入：grid = [[0,0,0,0,0,0,0,0]]
输出：0
```

```python
class Solution:
    def maxAreaOfIsland(self, grid: List[List[int]]) -> int:
        dir = [(-1,0),(1,0),(0,-1),(0,1)]
        m,n = len(grid),len(grid[0])
        ans = 0

        def dfs(grid,x,y):
            if not 0<=x<m or not 0<=y<n:
                return 0
            if grid[x][y] != 1:
                return 0
            grid[x][y] = 2
            count = 1  #函数内局部变量--当前算一个岛屿
            for dx,dy in dir:
                xx,yy = x+dx,y+dy
                count += dfs(grid,xx,yy)
            return count

        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1:
                    ans = max(ans,dfs(grid,i,j))

        return ans
```



#### [827. 最大人工岛](https://leetcode-cn.com/problems/making-a-large-island/) 

给你一个大小为 `n x n` 二进制矩阵 `grid` 。**最多** 只能将一格 `0` 变成 `1` 。

返回执行此操作后，`grid` 中最大的岛屿面积是多少？

**岛屿** 由一组上、下、左、右四个方向相连的 `1` 形成。

```
示例 1:
输入: grid = [[1, 0], [0, 1]]
输出: 3
解释: 将一格0变成1，最终连通两个小岛得到面积为 3 的岛屿。

示例 2:
输入: grid = [[1, 1], [1, 0]]
输出: 4
解释: 将一格0变成1，岛屿的面积扩大为 4。

示例 3:
输入: grid = [[1, 1], [1, 1]]
输出: 4
解释: 没有0可以让我们变成1，面积依然为 4。
```

两遍dfs:

+ 类似LC695-岛屿的最大面积, 首先计算最大岛屿面积；将各个岛屿进行编号，index放入grid中，用哈希表markIsland保存{index:size}
+ 对每个海洋（0）计算周围岛屿的总面积 --areas_dict

```python
class Solution:
    def largestIsland(self, grid: List[List[int]]) -> int:
        ## First, compute the area size of each island
        m, n = len(grid), len(grid[0])
        dir = [(-1,0),(1,0),(0,-1),(0,1)]
        idxIsland = 2 # Index the Islands from 2
        markIsland = dict()

        def inArea(i, j):
            return 0 <= i < m and 0 <= j < n

        def areaSize(idxIsland, i, j):
            if not inArea(i, j):
                return 0
            if grid[i][j] != 1:
                return 0
            grid[i][j] = idxIsland
            count = 1
            for di,dj in dir:
                ii,jj= i + di,j + dj
                count += areaSize(idxIsland, ii, jj)
            return count

        for i in range(m):       
            for j in range(n):
                if grid[i][j] == 1:
                    size = areaSize(idxIsland, i, j)
                    markIsland[idxIsland] = size
                    idxIsland += 1

        if len(markIsland) == 0:
            return 1

        if max(markIsland.values()) == m * n:
            return m * n

        ## Second, check each sea pixel and its neighbor islands' size
        def area_idx(i, j):
            if inArea(i, j):
                idx = grid[i][j]
                if idx == 0:
                    return 0, 0 
                size = markIsland[idx]
                return idx, size
            return 0, 0
        
        #compute the total size of neihgbor Islands
        def neighbor_areas(i, j):
            areas_dict = dict()
            for di,dj in dir:
                ii,jj= i + di,j + dj
                idx, size = area_idx(ii, jj)
                #save the area size of the neighbor islands
                if idx not in areas_dict:
                    areas_dict[idx] = size
            return sum(areas_dict.values())

        #compute the max area size with the extra sea connection
        res = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 0:
                    size = 1 + neighbor_areas(i, j)
                    res = max(res, size)
        return res
```



#### [463. 岛屿的周长](https://leetcode-cn.com/problems/island-perimeter/)

给定一个 `row x col` 的二维网格地图 `grid` ，其中：`grid[i][j] = 1` 表示陆地， `grid[i][j] = 0` 表示水域。

网格中的格子 **水平和垂直** 方向相连（对角线方向不相连）。整个网格被水完全包围，但其中恰好有一个岛屿（或者说，一个或多个表示陆地的格子相连组成的岛屿）。

岛屿中没有“湖”（“湖” 指水域在岛屿内部且不和岛屿周围的水相连）。格子是边长为 1 的正方形。网格为长方形，且宽度和高度均不超过 100 。计算这个岛屿的周长。

![img](https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2018/10/12/island.png)

```
输入：grid = [[0,1,0,0],[1,1,1,0],[0,1,0,0],[1,1,0,0]]
输出：16
解释：它的周长是上面图片中的 16 个黄色的边

示例 2：
输入：grid = [[1]]
输出：4
```

```python
#数学方法
class Solution:
    def islandPerimeter(self, grid: List[List[int]]) -> int:
        side = 0
        for l in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[l][c] == 0:
                    continue
                side += 4
                #若有重叠 -2
                if l != 0 and grid[l - 1][c] == 1: #左
                    side -= 2
                if c != 0 and grid[l][c - 1] == 1: #上
                    side -= 2
        return side
```

<img src="https://pic.leetcode-cn.com/66d817362c1037ebe7705aacfbc6546e321c2b6a2e4fec96791f47604f546638.jpg" alt="将岛屿周长中的边分为两类" style="zoom:50%;" />

```python
class Solution:
    def islandPerimeter(self, grid: List[List[int]]) -> int:

        dir = [(-1,0),(1,0),(0,-1),(0,1)]
        m,n = len(grid),len(grid[0])

        def dfs(grid,x,y):
            if not 0<=x<m or not 0<=y<n: #超出网格范围--一条黄色的边
                return 1
            if grid[x][y] == 0:          #当前格子是海洋格--一条蓝色的边
                return 1
            if grid[x][y] == 2:          #当前格子已遍历返回--无
                return 0
            grid[x][y] = 2
            count = 0
            for dx,dy in dir:             #遍历结果相加
                xx,yy = x+dx,y+dy
                count += dfs(grid,xx,yy)
            return count

        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1:       #只有一个岛屿
                    return dfs(grid,i,j)
```



#### [1254. 统计封闭岛屿的数目](https://leetcode-cn.com/problems/number-of-closed-islands/) 

有一个二维矩阵 `grid` ，每个位置要么是陆地（记号为 `0` ）要么是水域（记号为 `1` ）。

我们从一块陆地出发，每次可以往上下左右 4 个方向相邻区域走，能走到的所有陆地区域，我们将其称为一座「**岛屿**」。

如果一座岛屿 **完全** 由水域包围，即陆地边缘上下左右所有相邻区域都是水域，那么我们将其称为 「**封闭岛屿**」。

请返回封闭岛屿的数目。

![img](https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2019/11/07/sample_3_1610.png)

```
输入：grid = [[1,1,1,1,1,1,1,0],[1,0,0,0,0,1,1,0],[1,0,1,0,1,1,1,0],[1,0,0,0,0,1,0,1],[1,1,1,1,1,1,1,0]]
输出：2
解释：
灰色区域的岛屿是封闭岛屿，因为这座岛屿完全被水域包围（即被 1 区域包围）。
```

```python
class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        dir = [(-1,0),(1,0),(0,-1),(0,1)]
        m,n = len(grid),len(grid[0])

        def dfs(grid,x,y):
            if not 0<=x<m or not 0<=y<n:
                return
            if grid[x][y] != 0:
                return
            grid[x][y] = 2
            for dx,dy in dir:
                xx,yy = x+dx,y+dy
                dfs(grid,xx,yy)
        #边界dfs--填充陆地
        for i in range(m):
            dfs(grid,i, 0)
            dfs(grid,i, n-1)
        for j in range(n):
            dfs(grid,0, j)
            dfs(grid,m-1, j)
        #岛屿数量统计   
        ans = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 0:
                    ans += 1
                    dfs(grid,i,j)
        return ans
```



#### [1020. 飞地的数量](https://leetcode-cn.com/problems/number-of-enclaves/)

给出一个二维数组 `A`，每个单元格为 0（代表海）或 1（代表陆地）。

移动是指在陆地上从一个地方走到另一个地方（朝四个方向之一）或离开网格的边界。

返回网格中**无法**在任意次数的移动中离开网格边界的陆地单元格的数量。

```
输入：[[0,0,0,0],[1,0,1,0],[0,1,1,0],[0,0,0,0]]
输出：3
解释： 有三个 1 被 0 包围。一个 1 没有被包围，因为它在边界上。
```

```python
#其他类似1254  --填充边界
        ans = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1:
                    ans += 1
```



#### [130. 被围绕的区域](https://leetcode-cn.com/problems/surrounded-regions/)

给你一个 `m x n` 的矩阵 `board` ，由若干字符 `'X'` 和 `'O'` ，找到所有被 `'X'` 围绕的区域，并将这些区域里所有的 `'O'` 用 `'X'` 填充。

<img src="https://assets.leetcode.com/uploads/2021/02/19/xogrid.jpg" alt="img" style="zoom:50%;" />

```
输入：board = [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]]
输出：[["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]
解释：被围绕的区间不会存在于边界上，换句话说，任何边界上的 'O' 都不会被填充为 'X'。 任何不在边界上，或不与边界上的 'O' 相连的 'O' 最终都会被填充为 'X'。如果两个元素在水平或垂直方向相邻，则称它们是“相连”的。

示例 2：
输入：board = [["X"]]
输出：[["X"]]
```

```python
#其他类似1254  --填充边界为 'k'
        for i in range(m):
            for j in range(n):
                if grid[i][j] == '0':  #非边界为'X'
                    grid[i][j] = 'X'
                if grid[i][j] == 'K':  #边界还原为'O'
                    grid[i][j] = 'O'
		return grid
```



#### [1034. 边界着色](https://leetcode-cn.com/problems/coloring-a-border/)

给你一个大小为 `m x n` 的整数矩阵 `grid` ，表示一个网格。另给你三个整数 `row`、`col` 和 `color` 。网格中的每个值表示该位置处的网格块的颜色。

两个网格块属于同一 **连通分量** 需满足下述全部条件：

- 两个网格块颜色相同
- 在上、下、左、右任意一个方向上相邻

**连通分量的边界** 是指连通分量中满足下述条件之一的所有网格块：

- 在上、下、左、右四个方向上与不属于同一连通分量的网格块相邻
- 在网格的边界上（第一行/列或最后一行/列）

请你使用指定颜色 `color` 为所有包含网格块 `grid[row][col]` 的 **连通分量的边界** 进行着色，并返回最终的网格 `grid` 。

```
输入：grid = [[1,1],[1,2]], row = 0, col = 0, color = 3
输出：[[3,3],[3,2]]

输入：grid = [[1,2,2],[2,3,2]], row = 0, col = 1, color = 3
输出：[[1,3,3],[2,3,3]]

输入：grid = [[1,1,1],[1,1,1],[1,1,1]], row = 1, col = 1, color = 2
输出：[[2,2,2],[2,1,2],[2,2,2]]
```

```python
class Solution:
    def colorBorder(self, grid: List[List[int]], row: int, col: int, color: int) -> List[List[int]]:
        visited, m, n = set(), len(grid), len(grid[0])
        def dfs(x, y):
            if (x, y) in visited: 
                return True
            if not (0 <= x < m and 0 <= y < n and grid[x][y] == grid[row][col]): #超出边界+非连通
                return False
            #连通 --加入访问
            visited.add((x, y))
            if dfs(x+1, y) + dfs(x-1, y) + dfs(x, y+1) + dfs(x, y-1) < 4:  #绝了：边界必<4 ;中间--周围有非连通
                grid[x][y] = color
            return True

        dfs(row, col)
        return grid
```



#### [576. 出界的路径数](https://leetcode-cn.com/problems/out-of-boundary-paths/)

给你一个大小为 `m x n` 的网格和一个球。球的起始坐标为 `[startRow, startColumn]` 。你可以将球移到在四个方向上相邻的单元格内（可以穿过网格边界到达网格之外）。你 **最多** 可以移动 `maxMove` 次球。

给你五个整数 `m`、`n`、`maxMove`、`startRow` 以及 `startColumn` ，找出并返回可以将球移出边界的路径数量。因为答案可能非常大，返回对 `109 + 7` **取余** 后的结果。

<img src="https://assets.leetcode.com/uploads/2021/04/28/out_of_boundary_paths_1.png" alt="img" style="zoom:50%;" />

```
输入：m = 2, n = 2, maxMove = 2, startRow = 0, startColumn = 0
输出：6
```

```python
class Solution:
    def findPaths(self, m: int, n: int, maxMove: int, startRow: int, startColumn: int) -> int:
        @functools.lru_cache(None)
        def dfs(x, y, step):
            if step > maxMove:                     #次数用完，无法移动
                return 0
            ans = 0
            if x < 0 or x == m or y < 0 or y == n: #越界了即找到了一条路径
                return 1
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                ans += dfs(nx, ny, step + 1)
            return ans % mod
        mod = 10 ** 9 + 7
        return dfs(startRow, startColumn, 0)
```

```python
# DP2: AC (think reverse, the problem is equivalent to starting from outside, in k steps
# how many ways to arrive at postion (r, c))
class Solution:
    def findPaths(self, m, n, K, r, c):
        MOD = 1000000007
        dp = [[[0] * (n) for _ in range(m + 1)] for _ in range(K + 2)]
        res = 0
        for k in range(1, K + 1):
            for i in range(0, m):
                for j in range(0, n):
                    up = (1 if i == 0 else dp[k - 1][i - 1][j])
                    down = (1 if i == m - 1 else dp[k - 1][i + 1][j])
                    left = (1 if j == 0 else dp[k - 1][i][j - 1])
                    right = (1 if j == n - 1 else dp[k - 1][i][j + 1])
                    dp[k][i][j] = (up + down + left + right) % MOD
        return dp[K][r][c]
```

