### 函数

- 函数代码块以 **def** 关键词开头，后接函数标识符名称和圆括号 **()**。
- 任何传入参数和自变量必须放在圆括号中间，圆括号之间可以用于定义参数。
- 函数的第一行语句可以选择性地使用文档字符串—用于存放函数说明。
- 函数内容以冒号起始，并且缩进。
- **return [表达式]** 结束函数，选择性地返回一个值给调用方。不带表达式的return相当于返回 None。

```python
def 函数名（参数列表）:    #定义
    函数体
    return 表达式        #退出函数
```



#### 1.参数传递

- **不可变类型：**类似 c++ 的值传递，如 整数、字符串、元组。如fun（a），传递的只是a的值，没有影响a对象本身。比如在 fun（a）内部修改 a 的值，只是修改另一个复制的对象，不会影响 a 本身。
- **可变类型：**类似 c++ 的引用传递，如 列表，字典。如 fun（la），则是将 la 真正的传过去，修改后fun外部的la也会受影响



#### 2.参数类型

- 必需参数：必需参数须以正确的顺序传入函数。调用时的数量必须和声明时的一样。

  ```python
  def sum(a,b):
      sum = a + b
      return sum
  
  sum(1,2)
  ```

- 关键字参数：关键字参数允许函数调用时参数的顺序与声明时不一致

  ```python
  def sum(a,b):
      sum = a + b
      return sum
  
  sum(b=2,a=1)
  ```

- 默认参数：调用函数时，如果没有传递参数，则会使用默认参数。

- 默认参数的值是可变时，使用None进行描述，在函数值对为None的情况进行描述--系统只会计算一次默认值

```python
def sum(a,b=2):
    sum = a + b
    return sum

sum(1)
```

- 不定长参数

  + \* 的参数会以元组的形式导入 --位置参数

    ```python
    def s(*arg):
        print(arg)
    
    s(5,6)  #(5,6)
    ```

  + **的参数会以字典的形式导入 --关键字参数

    ```python
    def s(**arg):
        print(arg)
    
    s(a=5,b=6)  #{'a': 5, 'b': 6}
    ```

    

#### 3.匿名函数 (lambda)

```python
lambda [arg1 [,arg2,.....argn]]:expression
```

```python
a = lambda x,y: x*y 
print(a(3,7))
```



- function -- 函数
- iterable -- 一个或多个可迭代序列

（1）**filter函数**  根据一定的条件对给定的列表进行过滤

```python
#filter(function, iterable)

my_list = [2,3,4,5,6,7,8] 
new_list = list(filter(lambda a：(a / 3 == 2),my_list))
print(new_list)
#6
```

（2）**map函数**   依次在所定义的函数关系中迭代返回

```python
#map(function, iterable)

my_list = [2,3,4,5,6,7,8] 
new_list = list(map(lambda a:(a / 3！= 2)，my_list))
print(new_list)
#[true,true,true,true,false,true,true]
```

（3）**reduce函数**  对参数序列中元素进行累积

```python
#reduce(function, iterable)

from functools import reduce
sum = reduce（lambda a，b：a + b，[23,21,45,98]）
#187
```

(4) **推导式-**-代替 map 和filter（建议）--序列都可以使用

```python
a = [ _ for _ in range(1,11) ]
s = [x*2 for x in a]
#s=map(lambda x : x**2,a)
```

--比起map,可以方便进行过滤原列表

```python
ss = [x*2 for x in a if x%2 == 0]
#ss=map(lambda x : x**2,filter(lambda x : x%2==0,a))
```



#### 4.eval函数

eval(expression, globals=None, locals=None)

参数：

+ expression：这个参数是一个**字符串**，python会使用globals字典和locals字典作为全局和局部的命名空间，将expression当做一个python表达式进行解析和计算。

+ globals:  这个参数管控的是一个全局的命名空间，也就是我们在计算表达式的时候可以使用全局的命名空间中的函数，如果globals没有被提供，则使用python的全局命名空间。

+ locals：这个参数管控的是一个局部的命名空间，和globals类似，不过当它和globals中有重复的部分时，locals里的定义会覆盖掉globals中的，也就是当globals和locals中有冲突的部分时，locals说了算，它有决定权，以它的为准。如果locals没有被提供的话，则默认为globals。

```python
a=10;
print(eval("a+1"))   #11 10+1

a=10;
g={'a':4}
print(eval("a+1",g))  #5 4+1

a=10
b=20
c=30
g={'a':6,'b':8}
t={'b':100,'c':10} 
print(eval('a+b+c',g,t)) #116 6+100+10
```

应用：计算中缀算术表达式