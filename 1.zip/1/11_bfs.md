#### 基本概念

DFS 与 BFS 在寻找路径最不同的一点是：

+ DFS 是一条路走到黑，它适合用于 「是否存在一条路径」
+ BFS 是影分身，每次影分身都会在原基础上走一步，适合用于 「是否存在一条最短路径」。



大概分类：

+ 单向BFS

  都可以--但存在搜索爆炸的情况

+ 双向BFS --起点+终点分别出发

  + 创建「两个队列」分别用于两个方向的搜索；
  + 创建「两个哈希表」用于「解决相同节点重复搜索」和「记录转换次数」；
  + 为了尽可能让两个搜索方向“平均”，每次从队列中取值进行扩展时，先判断哪个队列容量较少；
    如果在搜索过程中「搜索到对方搜索过的节点」，说明找到了最短路径。

  <img src="https://pic.leetcode-cn.com/38dc5897de2b554ea606a92c5eada14b0e0030195334e9fd65943ed6d0f77c1d-image.png" alt="image.png" style="zoom:50%;" />

  eg:127 752 2059

+ 多源BFS--

  **「多源最短路」问题是求从「多个源点」到达「一个/多个汇点」的最短路径。**

  eg: 542 994





#### [剑指 Offer 13. 机器人的运动范围](https://leetcode-cn.com/problems/ji-qi-ren-de-yun-dong-fan-wei-lcof/)

地上有一个m行n列的方格，从坐标 `[0,0]` 到坐标 `[m-1,n-1]` 。一个机器人从坐标 `[0, 0] `的格子开始移动，它每次可以向左、右、上、下移动一格（不能移动到方格外），也不能进入行坐标和列坐标的数位之和大于k的格子。例如，当k为18时，机器人能够进入方格 [35, 37] ，因为3+5+3+7=18。但它不能进入方格 [35, 38]，因为3+5+3+8=19。请问该机器人能够到达多少个格子？

```
示例 1：
输入：m = 2, n = 3, k = 1
输出：3

示例 2：
输入：m = 3, n = 1, k = 0
输出：1
```

```python
#BFS
class Solution:
    def sum_rc(self,row,col):
        tmp = 0
        while row > 0:
            tmp += row % 10
            row //= 10
        while col > 0:
            tmp += col % 10
            col //= 10
        return tmp

    def movingCount(self, m: int, n: int, k: int) -> int:
        marked = set()  # 将访问过的点添加到集合marked中,从(0,0)开始
        queue = collections.deque()
        queue.append((0,0))
        while queue:
            x, y = queue.popleft()
            if (x,y) not in marked and self.sum_rc(x,y) <= k:
                marked.add((x,y)) 
                for dx, dy in [(1,0),(0,1)]:  # 仅考虑向右和向下即可
                    if 0 <= x + dx < m and 0 <= y + dy < n:
                        queue.append((x+dx,y+dy)) 
        return len(marked)
```



#### [127. 单词接龙](https://leetcode-cn.com/problems/word-ladder/)

#### [剑指 Offer II 108. 单词演变](https://leetcode-cn.com/problems/om3reC/)

在字典（单词列表） `wordList` 中，从单词 `beginWord` 和 `endWord` 的 **转换序列** 是一个按下述规格形成的序列：

- 序列中第一个单词是 `beginWord` 。
- 序列中最后一个单词是 `endWord` 。
- 每次转换只能改变一个字母。
- 转换过程中的中间单词必须是字典 `wordList` 中的单词。

给定两个长度相同但内容不同的单词 `beginWord` 和 `endWord` 和一个字典 `wordList` ，找到从 `beginWord` 到 `endWord` 的 **最短转换序列** 中的 **单词数目** 。如果不存在这样的转换序列，返回 0。

```
输入：beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
输出：5
解释：一个最短转换序列是 "hit" -> "hot" -> "dot" -> "dog" -> "cog", 返回它的长度 5。

输入：beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log"]
输出：0
解释：endWord "cog" 不在字典中，所以无法进行转换。
```

```python
from collections import defaultdict
from collections import deque
class Solution:
    def ladderLength(self, beginWord, endWord, wordList):
        # 建立通用list
        size, general_dic = len(beginWord), defaultdict(list)
        for w in wordList:
            for _ in range(size):
                general_dic[w[:_]+"*"+w[_+1:]].append(w)
        # BFS
        queue = deque()
        queue.append((beginWord, 1))  # 单词 + 层数
        mark_dic = defaultdict(bool)  # bool 的默认值是false，因此所有不在list里的是false
        mark_dic[beginWord] = True
        while queue:
            cur_word, level = queue.popleft()   # queue头出来一个
            for i in range(size):               # 找邻居，这里的所有邻居都在level+1层
                for neighbour in general_dic[cur_word[:i]+"*"+cur_word[i+1:]]:
                    if neighbour == endWord: 
                        return level + 1
                    if not mark_dic[neighbour]:
                        mark_dic[neighbour] = True
                        queue.append((neighbour, level+1))  #符合条件（neighbour + unmarked)的进去
        return 0
```



#### [752. 打开转盘锁](https://leetcode-cn.com/problems/open-the-lock/)

#### [剑指 Offer II 109. 开密码锁](https://leetcode-cn.com/problems/zlDJc7/)

你有一个带有四个圆形拨轮的转盘锁。每个拨轮都有10个数字： `'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'` 。每个拨轮可以自由旋转：例如把 `'9'` 变为 `'0'`，`'0'` 变为 `'9'` 。每次旋转都只能旋转一个拨轮的一位数字。

锁的初始数字为 `'0000'` ，一个代表四个拨轮的数字的字符串。

列表 `deadends` 包含了一组死亡数字，一旦拨轮的数字和列表里的任何一个元素相同，这个锁将会被永久锁定，无法再被旋转。

字符串 `target` 代表可以解锁的数字，你需要给出解锁需要的最小旋转次数，如果无论如何不能解锁，返回 `-1` 。

```
输入：deadends = ["0201","0101","0102","1212","2002"], target = "0202"
输出：6
解释：
可能的移动序列为 "0000" -> "1000" -> "1100" -> "1200" -> "1201" -> "1202" -> "0202"。
注意 "0000" -> "0001" -> "0002" -> "0102" -> "0202" 这样的序列是不能解锁的，
因为当拨动到 "0102" 时这个锁就会被锁定。
```

```python
class Solution:
    def openLock(self, deadends: List[str], target: str) -> int:
        def plus_one(s: str, i: int) -> str:
            s = list(s)
            s[i] = str((int(s[i]) + 1) % 10)
            return ''.join(s)
        
        def sub_one(s: str, i: int) -> str:
            s = list(s)
            s[i] = str((int(s[i]) + 10 - 1) % 10)
            return ''.join(s)


        us = set(deadends)
        if "0000" in us:
            return -1
        
        q = collections.deque()
        visited = set()
        visited.add("0000")
        q.append("0000")
        step = 0
        while q:
            for _ in range(len(q)):
                x = q.popleft()
                if x == target:
                    return step
                for i in range(4):
                    for y in [plus_one(x, i), sub_one(x, i)]:
                        if y not in visited and y not in us:
                            visited.add(y)
                            q.append(y)
            step += 1
        return -1
```



#### [2059. 转化数字的最小运算数](https://leetcode-cn.com/problems/minimum-operations-to-convert-number/)

给你一个下标从 **0** 开始的整数数组 `nums` ，该数组由 **互不相同** 的数字组成。另给你两个整数 `start` 和 `goal` 。

整数 `x` 的值最开始设为 `start` ，你打算执行一些运算使 `x` 转化为 `goal` 。你可以对数字 `x` 重复执行下述运算：

如果 `0 <= x <= 1000` ，那么，对于数组中的任一下标 `i`（`0 <= i < nums.length`），可以将 `x` 设为下述任一值：

- `x + nums[i]`
- `x - nums[i]`
- `x ^ nums[i]`（按位异或 XOR）

注意，你可以按任意顺序使用每个 `nums[i]` 任意次。使 `x` 越过 `0 <= x <= 1000` 范围的运算同样可以生效，但该该运算执行后将不能执行其他运算。

返回将 `x = start` 转化为 `goal` 的最小操作数；如果无法完成转化，则返回 `-1` 。

```
示例 1：
输入：nums = [1,3], start = 6, goal = 4
输出：2
解释：
可以按 6 → 7 → 4 的转化路径进行，只需执行下述 2 次运算：
- 6 ^ 1 = 7
- 7 ^ 3 = 4

示例 2：
输入：nums = [3,5,7], start = 0, goal = -4
输出：2
解释：
可以按 0 → 3 → -4 的转化路径进行，只需执行下述 2 次运算：
- 0 + 3 = 3
- 3 - 7 = -4
注意，最后一步运算使 x 超过范围 0 <= x <= 1000 ，但该运算仍然可以生效。
```

```python
class Solution:
    def minimumOperations(self, nums: List[int], start: int, goal: int) -> int:

        op1 = lambda x, y: x + y
        op2 = lambda x, y: x - y
        op3 = lambda x, y: x ^ y
        ops = [op1, op2, op3]   # 运算符列表
        vis = [False] * 1001   # 可操作范围内整数的访问情况
        q = deque([(start, 0)])
        vis[start] = True
        while q:
            x, step = q.popleft()
            # 枚举数组中的元素和操作符并计算新生成的数值
            for num in nums:
                for op in ops:
                    nx = op(x, num)
                    # 如果新生成的数值等于目标值，则返回对应操作数--bfs访问第一个满足，即为最少操作数
                    if nx == goal:
                        return step + 1
                    # 如果新生成的数值不位于可操作范围内或已经加入队列，不操作
                    # 如果新生成的数值位于可操作范围内且未被加入队列，则更改访问情况并加入队列
                    if 0 <= nx <= 1000 and vis[nx] is False:
                        vis[nx] = True
                        q.append((nx, step + 1))
        # 不存在从初始值到目标值的转化方案
        return -1
```



#### [542. 01 矩阵](https://leetcode-cn.com/problems/01-matrix/)

#### [剑指 Offer II 107. 矩阵中的距离](https://leetcode-cn.com/problems/2bCMpM/)

给定一个由 `0` 和 `1` 组成的矩阵 `mat` ，请输出一个大小相同的矩阵，其中每一个格子是 `mat` 中对应位置元素到最近的 `0` 的距离。

两个相邻元素间的距离为 `1` 。

![img](https://pic.leetcode-cn.com/1626667201-NCWmuP-image.png)

```
输入：mat = [[0,0,0],[0,1,0],[0,0,0]]
输出：[[0,0,0],[0,1,0],[0,0,0]]
```

```python
class Solution:
    def updateMatrix(self, matrix: List[List[int]]) -> List[List[int]]:
        m, n = len(matrix), len(matrix[0])
        dist = [[0] * n for _ in range(m)]
        zeroes_pos = [(i, j) for i in range(m) for j in range(n) if matrix[i][j] == 0]
        # 将所有的 0 添加进初始队列中
        q = collections.deque(zeroes_pos)
        seen = set(zeroes_pos)             #标记访问

        # 广度优先搜索
        while q:
            i, j = q.popleft()
            for ni, nj in [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]:
                if 0 <= ni < m and 0 <= nj < n and (ni, nj) not in seen:
                    dist[ni][nj] = dist[i][j] + 1
                    q.append((ni, nj))
                    seen.add((ni, nj))
        return dist
```



#### [994. 腐烂的橘子](https://leetcode-cn.com/problems/rotting-oranges/)

在给定的网格中，每个单元格可以有以下三个值之一：

- 值 `0` 代表空单元格；
- 值 `1` 代表新鲜橘子；
- 值 `2` 代表腐烂的橘子。

每分钟，任何与腐烂的橘子（在 4 个正方向上）相邻的新鲜橘子都会腐烂。

返回直到单元格中没有新鲜橘子为止所必须经过的最小分钟数。如果不可能，返回 `-1`。

**<img src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2019/02/16/oranges.png" alt="img" style="zoom:50%;" />**

```
输入：[[2,1,1],[1,1,0],[0,1,1]]
输出：4
```

```python
class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:
        row, col, time = len(grid), len(grid[0]), 0
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        queue = []
        # add the rotten orange to the queue
        for i in range(row):
            for j in range(col):
                if grid[i][j] == 2:
                    queue.append((i, j, time))
        # bfs
        while queue:
            i, j, time = queue.pop(0)
            for di, dj in directions:
                if 0 <= i + di < row and 0 <= j + dj < col and grid[i + di][j + dj] == 1:
                    grid[i + di][j + dj] = 2
                    queue.append((i + di, j + dj, time + 1))
        # if there are still fresh oranges, return -1
        for row in grid:
            if 1 in row: 
                return -1

        return time
```



#### 华为笔试题--机智的外卖员

<img src="C:\Users\DELL\Desktop\工作\华为\华为算法题\210707\3.jpg" alt="3" style="zoom:15%;" />

```python
from collections import deque
def step(n, m):
    if n >= m:
        return n-m
    queue = deque()
    queue.append((0, n))
    while queue:
        idx, nums = queue.popleft()
        if nums == m:
            return idx
        queue.append((idx + 1, nums * 2))
        queue.append((idx + 1, nums + 1))
        if nums-1 > 0:  
            queue.append((idx+1, nums - 1))

if __name__ == '__main__':
    ans = step(5, 17)
    print(ans)
```



#### [909. 蛇梯棋](https://leetcode-cn.com/problems/snakes-and-ladders/)

给你一个大小为 `n x n` 的整数矩阵 `board` ，方格按从 `1` 到 `n2` 编号，编号遵循 [转行交替方式](https://baike.baidu.com/item/牛耕式转行书写法/17195786) ，**从左下角开始** （即，从 `board[n - 1][0]` 开始）每一行交替方向。

玩家从棋盘上的方格 `1` （总是在最后一行、第一列）开始出发。

每一回合，玩家需要从当前方格 `curr` 开始出发，按下述要求前进：

- 选定目标方格next，目标方格的编号符合范围 [curr + 1, min(curr + 6, n2)]。
  - 该选择模拟了掷 **六面体骰子** 的情景，无论棋盘大小如何，玩家最多只能有 6 个目的地。
  - 传送玩家：如果目标方格 `next` 处存在蛇或梯子，那么玩家会传送到蛇或梯子的目的地。否则，玩家传送到目标方格 `next` 。 
  - 当玩家到达编号 `n2` 的方格时，游戏结束。

`r` 行 `c` 列的棋盘，按前述方法编号，棋盘格中可能存在 “蛇” 或 “梯子”；如果 `board[r][c] != -1`，那个蛇或梯子的目的地将会是 `board[r][c]`。编号为 `1` 和 `n2` 的方格上没有蛇或梯子。

注意，玩家在每回合的前进过程中最多只能爬过蛇或梯子一次：就算目的地是另一条蛇或梯子的起点，玩家也 **不能** 继续移动。

- 举个例子，假设棋盘是 `[[-1,4],[-1,3]]` ，第一次移动，玩家的目标方格是 `2` 。那么这个玩家将会顺着梯子到达方格 `3` ，但 **不能** 顺着方格 `3` 上的梯子前往方格 `4` 。

返回达到编号为 `n2` 的方格所需的最少移动次数，如果不可能，则返回 `-1`。

<img src="https://assets.leetcode.com/uploads/2018/09/23/snakes.png" alt="img" style="zoom:33%;" />

```
输入：board = [[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,35,-1,-1,13,-1],[-1,-1,-1,-1,-1,-1],[-1,15,-1,-1,-1,-1]]
输出：4
解释：
首先，从方格 1 [第 5 行，第 0 列] 开始。 
先决定移动到方格 2 ，并必须爬过梯子移动到到方格 15 。
然后决定移动到方格 17 [第 3 行，第 4 列]，必须爬过蛇到方格 13 。
接着决定移动到方格 14 ，且必须通过梯子移动到方格 35 。 
最后决定移动到方格 36 , 游戏结束。 
```

+ 二维转化为一维
+ 贪心的运用

```python
class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        n = len(board)

        def id2rc(idx):             #一维--矩阵二维
            #r, c = (idx - 1) // n, (idx - 1) % n
            r, c = divmod((idx - 1), n)
            if r % 2 == 1:
                c = n - 1 - c
            return n - 1 - r, c

        queue = deque([(1, 0)])     #一维dfs
        vis = {1}
        while queue:
            x, step = queue.popleft()
            if x == n * n:
                return step
            # 加入贪心：除蛇或者梯子的地方，要跳尽可能远，即保留为-1的最大nxt
            already = False
            for dx in range(6, 0, -1):
                nxt = x + dx
                if nxt > n * n:
                    continue
                if nxt not in vis:
                    i, j = id2rc(nxt)
                    vis.add(nxt)
                    if board[i][j] != -1:
                        queue.append((board[i][j], step + 1))
                    elif not already:  #为-1，就只加入一个
                        queue.append((nxt, step + 1))
                        already = True
        return -1
```



#### [863. 二叉树中所有距离为 K 的结点](https://leetcode-cn.com/problems/all-nodes-distance-k-in-binary-tree/) 

给定一个二叉树（具有根结点 `root`）， 一个目标结点 `target` ，和一个整数值 `K` 。

返回到目标结点 `target` 距离为 `K` 的所有结点的值的列表。 答案可以以任何顺序返回。

<img src="https://s3-lc-upload.s3.amazonaws.com/uploads/2018/06/28/sketch0.png" alt="img" style="zoom:50%;" />

```
输入：root = [3,5,1,6,2,0,8,null,null,7,4], target = 5, K = 2
输出：[7,4,1]
解释：所求结点为与目标结点（值为 5）距离为 2 的结点，值分别为 7，4，以及 1
注意: 输入的 "root" 和 "target" 实际上是树上的结点。上面的输入仅仅是对这些对象进行了序列化描述。
```

+ 以树建图 --邻接表，map {子节点：父节点}
  + 树的本质是**有向图**，思路为将树转化成无向图，然后以target节点为中心，向四周搜索
+ 防止两节点间互相循环--记录前置节点

```python
class Solution:
    def distanceK(self, root: TreeNode, target: TreeNode, k: int) -> List[int]:
        
        node_parent = dict()
        def dfs_find_parent(node):
            if node:
                if node.left:
                    node_parent[node.left] = node
                if node.right:
                    node_parent[node.right] = node
                dfs_find_parent(node.left)
                dfs_find_parent(node.right)
        dfs_find_parent(root)

        res = []
        def dfs(root, prenode, k):
            if k == 0:
                res.append(root.val)
                return
            if root.left and root.left != prenode:     #左子
                dfs(root.left, root, k-1)
            if root.right and root.right != prenode:   #右子
                dfs(root.right, root, k-1)
            if root in node_parent and node_parent[root] != prenode:  #父
                dfs(node_parent[root], root, k-1)
        dfs(target, None, k)

        return res
```



#### [815. 公交路线](https://leetcode-cn.com/problems/bus-routes/)

给你一个数组 `routes` ，表示一系列公交线路，其中每个 `routes[i]` 表示一条公交线路，第 `i` 辆公交车将会在上面循环行驶。

- 例如，路线 `routes[0] = [1, 5, 7]` 表示第 `0` 辆公交车会一直按序列 `1 -> 5 -> 7 -> 1 -> 5 -> 7 -> 1 -> ...` 这样的车站路线行驶。

现在从 `source` 车站出发（初始时不在公交车上），要前往 `target` 车站。 期间仅可乘坐公交车。

求出 **最少乘坐的公交车数量** 。如果不可能到达终点车站，返回 `-1` 。

```
输入：routes = [[1,2,7],[3,6,7]], source = 1, target = 6
输出：2
解释：最优策略是先乘坐第一辆公交车到达车站 7 , 然后换乘第二辆公交车到车站 6 。 

输入：routes = [[7,12],[4,5,15],[6],[15,19],[9,12,13]], source = 15, target = 12
输出：-1
```

+ 多源bfs --每次能坐的所有公交车，将它的所有站都标记为已到达(且加入队列)
+ set --去重

```python
class Solution:
    def numBusesToDestination(self, routes: List[List[int]], source: int, target: int) -> int:
        # 每个车站可以乘坐的公交车
        stations = defaultdict(set)
        for i, stops in enumerate(routes):
            for stop in stops:
                stations[stop].add(i)
        # 每个公交车线路可以到达的车站
        routes = [set(x) for x in routes]

        q = deque([(source, 0)])
        # 已经乘坐了的公交车
        buses = set()
        # 已经到达了的车站
        stops = {source}
        while q:
            pos, cost = q.popleft()
            if pos == target:
                return cost
            # 当前车站中尚未乘坐的公交车
            for bus in stations[pos] - buses:
                # 该公交车尚未到达过的车站
                for stop in routes[bus] - stops:
                    buses.add(bus)
                    stops.add(stop)
                    q.append((stop, cost + 1))
        return -1
```



#### [310. 最小高度树](https://leetcode-cn.com/problems/minimum-height-trees/)

树是一个无向图，其中任何两个顶点只通过一条路径连接。 换句话说，一个任何没有简单环路的连通图都是一棵树。

给你一棵包含 `n` 个节点的树，标记为 `0` 到 `n - 1` 。给定数字 `n` 和一个有 `n - 1` 条无向边的 `edges` 列表（每一个边都是一对标签），其中 `edges[i] = [ai, bi]` 表示树中节点 `ai` 和 `bi` 之间存在一条无向边。

可选择树中任何一个节点作为根。当选择节点 `x` 作为根节点时，设结果树的高度为 `h` 。在所有可能的树中，具有最小高度的树（即，`min(h)`）被称为 **最小高度树** 。

请你找到所有的 **最小高度树** 并按 **任意顺序** 返回它们的根节点标签列表。

树的 **高度** 是指根节点和叶子节点之间最长向下路径上边的数量。

<img src="https://assets.leetcode.com/uploads/2020/09/01/e1.jpg" alt="img" style="zoom:50%;" />

```
输入：n = 4, edges = [[1,0],[1,2],[1,3]]
输出：[1]
解释：如图所示，当根是标签为 1 的节点时，树的高度是 1 ，这是唯一的最小高度树。
```

```python
lass Solution:
    def findMinHeightTrees(self, n: int, edges: List[List[int]]) -> List[int]:
        res = []
        if n==1:
            res.append(0)
            return res
        degree = [0]*n #记录每个点的度
        map = defaultdict(list) #存储邻居节点
        # 初始化无向图：每个节点的度和邻居
        for edge in edges:
            degree[edge[0]]+=1
            degree[edge[1]]+=1
            map[edge[0]].append(edge[1])
            map[edge[1]].append(edge[0])
        
        # 记录度为1的叶子节点
        queue = deque()
        for i in range(n):
            if degree[i]==1:
                queue.append(i)
        
        #每次遍历叶子节点，每一轮将叶子节点从树上删除后将新的叶子节点入队进行下一轮遍历
        while queue:
            res = []
            size = len(queue)
            # 遍历叶子节点
            for i in range(size):
                cur = queue.popleft()
                res.append(cur)
                neighbors = map[cur]
                for neighbor in neighbors:
                    # 将叶子节点的邻居节点的度减一，若是新的叶子节点，则入队
                    degree[neighbor]-=1
                    if degree[neighbor]==1:
                        queue.append(neighbor)
        # 返回最后一轮的叶子节点，就是最小高度树的根节点
        return res
```



#### [1245. 树的直径](https://leetcode-cn.com/problems/tree-diameter/)

给你这棵「无向树」，请你测算并返回它的「直径」：这棵树上最长简单路径的 **边数**。

我们用一个由所有「边」组成的数组 `edges` 来表示一棵无向树，其中 `edges[i] = [u, v]` 表示节点 `u` 和 `v` 之间的双向边。

树上的节点都已经用 `{0, 1, ..., edges.length}` 中的数做了标记，每个节点上的标记都是独一无二的。

<img src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2019/10/31/1397_example_1.png" alt="img" style="zoom: 50%;" />

```
输入：edges = [[0,1],[0,2]]
输出：2
解释：
这棵树上最长的路径是 1 - 0 - 2，边数为 2。
```

<img src="https://assets.leetcode-cn.com/aliyun-lc-upload/uploads/2019/10/31/1397_example_2.png" alt="img" style="zoom:50%;" />

```
输入：edges = [[0,1],[1,2],[2,3],[1,4],[4,5]]
输出：4
解释： 
这棵树上最长的路径是 3 - 2 - 1 - 4 - 5，边数为 4。
```

```
（1）类似最小高度树
（2）从叶子（degree==1）到根做BFS，记录节点的层数，每一层对应2的距离（最后一层除外:step-1）。
（3）记录最后一层：节点1:0；节点2:1 --无向图最后一层必 <=2
```