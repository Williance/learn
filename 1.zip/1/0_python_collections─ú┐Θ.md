## collections模块

这个模块实现了特定目标的容器，以提供Python标准内建容器 [`dict`](https://docs.python.org/zh-cn/3/library/stdtypes.html#dict) , [`list`](https://docs.python.org/zh-cn/3/library/stdtypes.html#list) , [`set`](https://docs.python.org/zh-cn/3/library/stdtypes.html#set) , 和 [`tuple`](https://docs.python.org/zh-cn/3/library/stdtypes.html#tuple) 的替代选择。

| [`namedtuple()`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.namedtuple) | 创建命名元组子类的工厂函数                                   |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| [`deque`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.deque) | 类似列表(list)的容器，实现了在两端快速添加(append)和弹出(pop) |
| [`ChainMap`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.ChainMap) | 类似字典(dict)的容器类，将多个映射集合到一个视图里面         |
| [`Counter`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.Counter) | 字典的子类，提供了可哈希对象的计数功能                       |
| [`OrderedDict`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.OrderedDict) | 字典的子类，保存了他们被添加的顺序                           |
| [`defaultdict`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.defaultdict) | 字典的子类，提供了一个工厂函数，为字典查询提供一个默认值     |
| [`UserDict`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.UserDict) | 封装了字典对象，简化了字典子类化                             |
| [`UserList`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.UserList) | 封装了列表对象，简化了列表子类化                             |
| [`UserString`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.UserString) | 封装了字符串对象，简化了字符串子类化                         |



### deque 双向队列

```python
from collections import deque
d = deque('ghi')                 #创建

d.append('j')                    #添加右端
d.appendleft('f')                #添加左端
#deque(['f', 'g', 'h', 'i', 'j'])
d.pop()                          #右端弹出--'j'   为空报错
d.popleft()                      #左端弹出--'f'   为空报错
dl = list(d)                     #列表形式--['g', 'h', 'i']

d.extend('jkl')                  #顺序添加多元素（字符串）
#deque(['g', 'h', 'i', 'j', 'k', 'l'])
d.extendleft('abc')              #逆序添加多元素（字符串）
#deque(['g', 'h', 'i','j', 'k', 'l','c', 'b', 'a'])
d.rotate(1)                      #右移
#deque(['l', 'g', 'h', 'i', 'j', 'k'])
d.rotate(-1)                     #左移
#deque(['g', 'h', 'i', 'j', 'k', 'l'])

#与list类似
d.clear()                        #清空
d.copy()                         #浅拷贝
reversed(d)                      #逆序排列      --deque(['i', 'h', 'g'])
'h' in d                         #in 存在？ --True
d.count('g')                     #计数
d.insert(i, x)                   #在位置i插入x
```



### Counter 计数功能的字典

一个 [`Counter`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.Counter) 是一个 [`dict`](https://docs.python.org/zh-cn/3/library/stdtypes.html#dict) 的子类，用于计数可哈希对象。它是一个集合，元素像字典键(key)一样存储，它们的计数存储为值。计数可以是任何整数值，包括0和负数。

```python
from collections import Counter
#初始化
c = Counter()                           # a new, empty counter
c = Counter('gallahad')                 # a new counter from an iterable
c = Counter({'red': 4, 'blue': 2})      # a new counter from a mapping
c = Counter(cats=4, dogs=8)             # a new counter from keyword args

c.elements()      #返回一个迭代器，元素会按首次出现的顺序返回，按计数值所指定次出现
c.most_common(n)  #元组列表，其中包含 n 个最常见的元素及出现次数，由高到低排序；无n则返回全部

sum(c.values())                 # total of all counts
c.clear()                       # reset all counts
list(c)                         # list unique elements
set(c)                          # convert to a set
dict(c)                         # convert to a regular dictionary
c.items()                       # convert to a list of (elem, cnt) pairs
Counter(dict(list_of_pairs))    # convert from a list of (elem, cnt) pairs

#数学操作
c = Counter(a=2, b=-4)
d = Counter(a=1, b=2)
c + d                       # add two counters together:  c[x] + d[x]
c - d                       # subtract (keeping only positive counts)
c & d                       # intersection:  min(c[x], d[x]) 
c | d                       # union:  max(c[x], d[x])
+c                          # 从空计数器加 Counter({'a': 2})，负不显示
-c                          #         减 Counter({'b': 4})       
```



### defaultdict

返回一个新的类似字典的对象。 [`defaultdict`](https://docs.python.org/zh-cn/3/library/collections.html?highlight=collection#collections.defaultdict) 是内置 [`dict`](https://docs.python.org/zh-cn/3/library/stdtypes.html#dict) 类的子类。 它重载了一个方法并添加了一个可写的实例变量。 其余的功能与 [`dict`](https://docs.python.org/zh-cn/3/library/stdtypes.html#dict) 类相同

`defaultdict`(*default_factory=None)*

第一个参数为default_factory属性提供初始值，默认为None。它覆盖一个方法并添加一个可写实例变量。**它的其他功能与dict相同，但会为一个不存在的键提供默认值**，从而避免KeyError异常。

```python
from collections import defaultdict

s = [('yellow', 1), ('blue', 2), ('yellow', 3), ('blue', 4), ('red', 1)]
d = defaultdict(list)
for k, v in s:
    d[k].append(v)
print(dict(d))
#{'yellow': [1, 3], 'blue': [2, 4], 'red': [1]}

d = defaultdict(set)
for k, v in s:
    d[k].add(v)
print(dict(d))
#{'yellow': {1, 3}, 'blue': {2, 4}, 'red': {1}}

s = 'mississippi'     #计数
d = defaultdict(int)
for k in s:
    d[k] += 1
print(dict(d))
#{'m': 1, 'i': 4, 's': 4, 'p': 2}
```

https://blog.csdn.net/lengfengyuyu/article/details/85003408



### **OrderedDict**

- `popitem`(*last=True*)[¶](https://docs.python.org/3.11/library/collections.html?highlight=ordereddict#collections.OrderedDict.popitem)

  The [`popitem()`](https://docs.python.org/3.11/library/collections.html?highlight=ordereddict#collections.OrderedDict.popitem) method for ordered dictionaries returns and removes a (key, value) pair. The pairs are returned in LIFO order if *last* is true or FIFO order if false.

  ```python
  popitem()            #尾  LIFO
  popitem(last=false)  #头  FIFO
  ```

- `move_to_end`(*key*, *last=True*)

  Move an existing *key* to either end of an ordered dictionary. The item is moved to the right end if *last* is true (the default) or to the beginning if *last* is false. Raises [`KeyError`](https://docs.python.org/3.11/library/exceptions.html#KeyError) if the *key* does not exist:

```python
>>> d = OrderedDict.fromkeys('abcde')
>>> d.move_to_end('b')
>>> ''.join(d.keys())
'acdeb'
>>> d.move_to_end('b', last=False)
>>> ''.join(d.keys())
'bacde'
```

--哈希表+双向链表（LRU）