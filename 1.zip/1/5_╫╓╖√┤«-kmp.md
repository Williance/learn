### 一，基本原理

####  一，KMP作用

KMP主要应用在字符串匹配上。

KMP的主要思想是**当出现字符串不匹配时，可以知道一部分之前已经匹配的文本内容，可以利用这些信息避免从头再去做匹配了。**

#### 二，最长公共前后缀

（1）正确理解前后缀

前缀是指不包含最后一个字符的所有以第一个字符开头的连续子串；

后缀是指不包含第一个字符的所有以最后一个字符结尾的连续子串。

（2）**前缀表要求的就是相同前后缀的长度。**



#### 三，前缀表（prefix table）

模式串（needle）：记录下标i之前（包括i）的字符串中，有**多大长度**的相同前缀后缀。（最长）

![KMP精讲8](https://code-thinking.cdn.bcebos.com/pics/KMP%E7%B2%BE%E8%AE%B28.png)

前缀表的作用：

前缀表是用来**回退**的，它记录了模式串（needle）与文本串（haystack）不匹配的时候，模式串应该从哪里开始重新匹配。

![KMP精讲2](https://code-thinking.cdn.bcebos.com/gifs/KMP%E7%B2%BE%E8%AE%B22.gif)

#### 四，前缀表与next数组

next数组就可以是前缀表，但是很多实现都是**把前缀表统一减一**（右移一位，初始位置为-1）之后作为next数组。

![KMP精讲4](https://code-thinking.cdn.bcebos.com/gifs/KMP%E7%B2%BE%E8%AE%B24.gif)

#### 五，时间复杂度分析

其中n为文本串长度，m为模式串长度，因为在匹配的过程中，根据前缀表不断调整匹配的位置，可以看出匹配的过程是O(n)，之前还要单独生成next数组，时间复杂度是O(m)。所以整个KMP算法的时间复杂度是**O(n+m)**的。

暴力的解法显而易见是**O(n * m）**



### 二，具体算法实现

#### 一， 构造next数组

1. 初始化
2. 处理前后缀不相同的情况
3. 处理前后缀相同的情况

```python
def getnext(self,needle):
    #对next数组进行初始化赋值
    #定义两个指针i和j，j指向前缀起始位置，i指向后缀起始位置。
	next = ['' for i in range(a)]
	j = -1  #j初始化为 -1,next数组为前缀表统一减1
	next[0] = j #next[i] 表示 i（包括i）之前最长相等的前后缀长度（其实就是j）
    #i 从1开始遍历
	for i in range(1,len(needle)):
        # needle[i] 与 needle[j+1] 不相同，向前回退，即找j+1前一个元素在next数组里的值（就是next[j]）
		while (j > -1 and needle[j+1] != needle[i]):
			j = next[j]
        #needle[i] 与 needle[j+1] 相同，同时向后移动i 和j 此时找到了相同的前后缀，且将j（最长相等的前后缀长度）赋给next[i]
		if needle[j+1] == needle[i]:
			j += 1
		next[i] = j
	return next
```

![KMP精讲3](https://code-thinking.cdn.bcebos.com/gifs/KMP%E7%B2%BE%E8%AE%B23.gif)

#### 二，使用next数组来做匹配

1. 初始化
2. 处理needle[m+1],haystack[n]不相同的情况
3. 处理needle[m+1],haystack[n]相同的情况

```python
def strStr(self, haystack: str, needle: str) -> int:
	a = len(needle)
	b = len(haystack)
	if a == 0:    #模式串为空，返回0
		return 0
    #定义两个下标 m指向模式串起始位置，n指向文本串起始位置
	next = self.getnext(needle)
	m = -1
    #n就从0开始，遍历文本串
	for n in range(b):
        #如果needle[m+1],haystack[n]不相同，向前回退寻找下一个匹配的位置，即找m+1前一个元素在next数组里的值（next[m]）
		while m >= 0 and needle[m+1]!=haystack[n]:
			m = next[m]
        #如果needle[m+1],haystack[n]相同,同时向后移动m和n
		if needle[m+1] == haystack[n]:
			m += 1
        #当m指向needle的末尾，即模式串完全匹配文本串了
		if m == a-1:
            #此时包括n,之前的文本串长度 - 模式串的长度
			return n+1-a
	return -1
```



### 三，相关题目

#### 28.实现 strStr()--经典

https://leetcode-cn.com/problems/implement-strstr/

实现 strStr() 函数。

给定一个 haystack 字符串和一个 needle 字符串，在 haystack 字符串中找出 needle 字符串出现的第一个位置 (从0开始)。如果不存在，则返回 -1。

```
示例 1: 输入: haystack = "hello", needle = "ll" 输出: 2
示例 2: 输入: haystack = "aaaaa", needle = "bba" 输出: -1

说明: 当 needle 是空字符串时，我们应当返回什么值呢？这是一个在面试中很好的问题。 对于本题而言，当 needle 是空字符串时我们应当返回 0 。这与C语言的 strstr() 以及 Java的 indexOf() 定义相符。
```

```python
str.find(str, beg=0, end=len(string))
#str -- 指定检索的字符串
#beg -- 开始索引，默认为0。
#end -- 结束索引，默认为字符串的长度。
```



####  459.重复的子字符串

https://leetcode-cn.com/problems/repeated-substring-pattern/

给定一个非空的字符串，判断它是否可以由它的一个子串重复多次构成。给定的字符串只含有小写英文字母，并且长度不超过10000。

```
示例 1: 输入: "abab" 输出: True 解释: 可由子字符串 "ab" 重复两次构成。
示例 2: 输入: "aba" 输出: False
示例 3: 输入: "abcabcabcabc" 输出: True 解释: 可由子字符串 "abc" 重复四次构成。 (或者子字符串 "abcabc" 重复两次构成。)
```

（1）双倍字符串ss

+ 当 s 没有循环节时：
  如果 s 中没有循环节，那么 ss 中必然有且只有两个 s，此时从 ss[1] 处开始寻找 s ，必然只能找到第二个，所以此时返回值为 len(s)

<img src="https://pic.leetcode-cn.com/1598227887-eIftIu-image.png" alt="image.png" style="zoom:50%;" />

+ 当 s 有循环节时：
  当 s 中有循环节时，设循环节为 r，其长度为 l，那么 ss 中必然有 s.size()/l + 1 个 s。
  因为去掉了第一个 S 的第一个字符 (代码中，(s+s).find(s, 1)， 是从 ss[1] 处开始 find )
  所以此时必回找到第二个 s 的起点。

<img src="https://pic.leetcode-cn.com/1598228553-dXojLo-image.png" alt="image.png" style="zoom:50%;" />

```python
class Solution:
    def repeatedSubstringPattern(self, s: str) -> bool:
        return (s + s).find(s, 1) != len(s)
```

(2)KMP

如果 next[len - 1] != -1，则说明字符串有最长相同的前后缀（就是字符串里的前缀子串和后缀子串相同的最长长度）。

最长相等前后缀的长度为：next[len - 1] + 1。

数组长度为：len。

如果len % (len - (next[len - 1] + 1)) == 0 ，则说明 (数组长度-最长相等前后缀的长度) 正好可以被 数组的长度整除，说明有该字符串有重复的子字符串。

**数组长度减去最长相同前后缀的长度相当于是第一个周期的长度，也就是一个周期的长度，如果这个周期可以被整除，就说明整个数组就是这个周期的循环。**

```python
class Solution:
    def repeatedSubstringPattern(self, s: str) -> bool:  
        if len(s) == 0:
            return False
        nxt = [0] * len(s)
        self.getNext(nxt, s)
        if nxt[-1] != -1 and len(s) % (len(s) - (nxt[-1] + 1)) == 0:
            return True
        return False
    
    def getNext(self, nxt, s):
        nxt[0] = -1
        j = -1
        for i in range(1, len(s)):
            while j >= 0 and s[i] != s[j+1]:
                j = nxt[j]
            if s[i] == s[j+1]:
                j += 1
            nxt[i] = j
        return nxt
```



#### [686. 重复叠加字符串匹配](https://leetcode-cn.com/problems/repeated-string-match/)

给定两个字符串 `a` 和 `b`，寻找重复叠加字符串 `a` 的最小次数，使得字符串 `b` 成为叠加后的字符串 `a` 的子串，如果不存在则返回 `-1`。

**注意：**字符串 `"abc"` 重复叠加 0 次是 `""`，重复叠加 1 次是 `"abc"`，重复叠加 2 次是 `"abcabc"`。

```
输入：a = "abcd", b = "cdabcdab"
输出：3
解释：a 重复叠加三遍后为 "abcdabcdabcd", 此时 b 是其子串。

输入：a = "a", b = "aa"
输出：2
```

--l = math.ceil(len(b) / len(a))

--覆盖b字符串至少需要 l , 至多需要 l+1 个a字符串

```python
class Solution:
    def repeatedStringMatch(self, a: str, b: str) -> int:
        import math
        l = math.ceil(len(b) / len(a))
        if (a * l).find(b) != -1:
            return l
        elif (a * (l + 1)).find(b) != -1:
            return l + 1
        else:
            return -1
```

